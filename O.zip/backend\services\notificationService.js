const { NotificationLog } = require('../models/dataRepository');

class NotificationService {
  constructor() {
    this.io = null;
  }

  setSocketIO(io) {
    this.io = io;
  }

  async broadcastDisasterAlert(alert) {
    const timestamp = new Date().toISOString();

    const pushPayload = {
      channel: 'web_push',
      recipient: 'all_active_citizens',
      title: `EMERGENCY ALERT: ${alert.title}`,
      message: `${alert.description} Area: ${alert.location.area}. Take immediate precautions.`,
      severity: alert.severity,
      timestamp
    };

    const smsPayload = {
      channel: 'sms_gateway',
      recipient: `Registered Citizens in ${alert.location.area}`,
      title: `[NDMA ALERT] ${alert.title}`,
      message: `${alert.type.toUpperCase()} WARNING in ${alert.location.area}. Follow official evacuation directions. Dial 112 for SOS.`,
      timestamp,
      status: 'SENT'
    };

    const emailPayload = {
      channel: 'email_broadcast',
      recipient: 'registered_community@disaster-response.gov',
      title: `URGENT: ${alert.title}`,
      message: `Detailed advisory: ${alert.description}\nSafe shelters are activated.\nEmergency Instructions:\n${(alert.instructions || []).join('\n')}`,
      timestamp,
      status: 'DELIVERED'
    };

    // Store in audit log
    await NotificationLog.create(pushPayload);
    await NotificationLog.create(smsPayload);
    await NotificationLog.create(emailPayload);

    // Broadcast in real-time over WebSocket
    if (this.io) {
      this.io.emit('emergency_broadcast', {
        alert,
        notification: pushPayload
      });
    }

    console.log(`[NotificationService] Multi-channel broadcast dispatched for alert: "${alert.title}"`);
    return { pushPayload, smsPayload, emailPayload };
  }

  async notifyAuthorityNewReport(report) {
    const log = {
      channel: 'authority_dispatch_alert',
      recipient: 'emergency_response_command',
      title: `NEW CITIZEN SOS: ${report.disasterType.toUpperCase()}`,
      message: `Reported at ${report.location.address}. Victims: ${report.victimsCount || 0}`,
      timestamp: new Date().toISOString()
    };

    await NotificationLog.create(log);

    if (this.io) {
      this.io.emit('new_incident_report', report);
    }
    return log;
  }

  async notifyReportStatusUpdate(report) {
    if (this.io) {
      this.io.emit('incident_status_updated', report);
    }
  }
}

module.exports = new NotificationService();
