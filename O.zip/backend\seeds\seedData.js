const bcrypt = require('bcryptjs');
const { collections } = require('../services/storageAdapter');

async function seedDatabase() {
  console.log('[Seed] Seeding sample disaster response data...');

  // 1. Seed Users
  const salt = await bcrypt.genSalt(10);
  const officerPass = await bcrypt.hash('Officer123!', salt);
  const citizenPass = await bcrypt.hash('Citizen123!', salt);

  const demoUsers = [
    {
      _id: 'user_officer_01',
      name: 'Inspector Rajesh Kumar (NDRF Officer)',
      email: 'officer@disaster-response.gov',
      password: officerPass,
      phone: '+91-9876543210',
      role: 'authority',
      location: { city: 'Hyderabad', lat: 17.3850, lng: 78.4867 }
    },
    {
      _id: 'user_citizen_01',
      name: 'Sai Lahari (Citizen Resident)',
      email: 'citizen@example.com',
      password: citizenPass,
      phone: '+91-9123456789',
      role: 'citizen',
      location: { city: 'Hyderabad', lat: 17.3916, lng: 78.4745 }
    }
  ];

  collections.users.clear();
  demoUsers.forEach(u => collections.users.create(u));

  // 2. Seed Alerts
  const sampleAlerts = [
    {
      _id: 'alert_01',
      title: 'CRITICAL: Severe Cyclone "Varun" Landfall Warning',
      type: 'cyclone',
      severity: 'critical',
      description: 'Severe cyclonic storm moving at 120 km/h with heavy squalls and storm surges expected within 6 hours. High risk of uprooted trees and tidal inundation.',
      location: {
        area: 'Coastal Bay Region',
        city: 'Visakhapatnam / Kakinada Coast',
        lat: 17.6868,
        lng: 83.2185,
        radiusKm: 25
      },
      instructions: [
        'Move immediately to designated concrete disaster shelters',
        'Disconnect electrical appliances and main switches',
        'Stock at least 3 days of potable water and non-perishable food',
        'Fishermen advised not to venture into deep sea waters'
      ],
      source: 'India Meteorological Department & NDMA',
      active: true,
      issuedAt: new Date(Date.now() - 1000 * 60 * 30).toISOString()
    },
    {
      _id: 'alert_02',
      title: 'FLASH FLOOD: River Inundation & Low-Lying Breach',
      type: 'flood',
      severity: 'critical',
      description: 'Intense 180mm downpour in catchment zone has breached minor dam outlets. Rapid water level rise of 1.8 meters across Musi / Godavari riverbanks.',
      location: {
        area: 'Old City & Riverbank Lowlands',
        city: 'Hyderabad',
        lat: 17.3616,
        lng: 78.4747,
        radiusKm: 12
      },
      instructions: [
        'Evacuate ground floors and move to first floor or relief centers immediately',
        'Do not attempt to drive through flooded roads or underpasses',
        'Keep emergency whistle and flashlights accessible',
        'Report trapped families via the SOS Reporting button'
      ],
      source: 'State Disaster Management Authority (SDMA)',
      active: true,
      issuedAt: new Date(Date.now() - 1000 * 60 * 90).toISOString()
    },
    {
      _id: 'alert_03',
      title: 'SEISMIC ADVISORY: Magnitude 5.4 Tremor Recorded',
      type: 'earthquake',
      severity: 'high',
      description: 'Shallow earthquake recorded at 12km depth. Secondary tremors and structural cracks reported in older masonry structures.',
      location: {
        area: 'Eastern Foothills Fault Zone',
        city: 'Vijayawada',
        lat: 16.5062,
        lng: 80.6480,
        radiusKm: 18
      },
      instructions: [
        'Practice DROP, COVER, and HOLD ON under sturdy tables',
        'Stay clear of glass windows, mirrors, and outer facades',
        'Do not use elevators; use external fire escape stairs',
        'Check for gas leaks before lighting matches or switches'
      ],
      source: 'National Center for Seismology',
      active: true,
      issuedAt: new Date(Date.now() - 1000 * 60 * 240).toISOString()
    },
    {
      _id: 'alert_04',
      title: 'WILDFIRE WATCH: Forest Dry Season Flare-Up',
      type: 'wildfire',
      severity: 'moderate',
      description: 'Rapidly spreading brush fire fueled by 45 km/h winds approaching suburban fringe. Thick smoke plume reducing visibility.',
      location: {
        area: 'Ridge Forest Reserve Buffer Zone',
        city: 'Hyderabad Outskirts',
        lat: 17.4500,
        lng: 78.3600,
        radiusKm: 8
      },
      instructions: [
        'Close all windows, vents, and air circulation dampers',
        'Prepare grab-and-go emergency documentation bags',
        'Wet outdoor perimeter plants and roofs if hose is available'
      ],
      source: 'Forest Fire Surveillance Cell',
      active: true,
      issuedAt: new Date(Date.now() - 1000 * 60 * 400).toISOString()
    }
  ];

  collections.alerts.clear();
  sampleAlerts.forEach(a => collections.alerts.create(a));

  // 3. Seed Shelters & Hospitals
  const sampleShelters = [
    {
      _id: 'shelter_01',
      name: 'Dr. B.R. Ambedkar Disaster Relief Stadium Shelter',
      type: 'shelter',
      location: {
        address: 'Sector 4, Central Sports Complex, Basheerbagh',
        city: 'Hyderabad',
        lat: 17.4005,
        lng: 78.4735
      },
      totalCapacity: 800,
      currentOccupancy: 310,
      availableBeds: 490,
      hasMedicalAid: true,
      hasFoodWater: true,
      contactPhone: '+91-40-23456789',
      status: 'open'
    },
    {
      _id: 'shelter_02',
      name: 'Osmania General Hospital - Emergency Trauma Wing',
      type: 'hospital',
      location: {
        address: 'Afzal Gunj, High Court Road',
        city: 'Hyderabad',
        lat: 17.3713,
        lng: 78.4754
      },
      totalCapacity: 350,
      currentOccupancy: 275,
      availableBeds: 75,
      hasMedicalAid: true,
      hasFoodWater: true,
      contactPhone: '+91-40-24600121',
      status: 'open'
    },
    {
      _id: 'shelter_03',
      name: 'Red Cross Community Emergency Evacuation Camp',
      type: 'shelter',
      location: {
        address: 'Plot 18, Red Cross Road, Narayanaguda',
        city: 'Hyderabad',
        lat: 17.3968,
        lng: 78.4912
      },
      totalCapacity: 500,
      currentOccupancy: 140,
      availableBeds: 360,
      hasMedicalAid: true,
      hasFoodWater: true,
      contactPhone: '+91-40-27633211',
      status: 'open'
    },
    {
      _id: 'shelter_04',
      name: 'Gandhi Memorial Government Medical Hospital',
      type: 'hospital',
      location: {
        address: 'Musheerabad, Padmarao Nagar',
        city: 'Secunderabad',
        lat: 17.4243,
        lng: 78.5029
      },
      totalCapacity: 600,
      currentOccupancy: 490,
      availableBeds: 110,
      hasMedicalAid: true,
      hasFoodWater: true,
      contactPhone: '+91-40-27505566',
      status: 'open'
    },
    {
      _id: 'shelter_05',
      name: 'Municipal High School Cyclone & Flood Shelter',
      type: 'shelter',
      location: {
        address: 'Ward 12, Malakpet East',
        city: 'Hyderabad',
        lat: 17.3742,
        lng: 78.5065
      },
      totalCapacity: 300,
      currentOccupancy: 85,
      availableBeds: 215,
      hasMedicalAid: false,
      hasFoodWater: true,
      contactPhone: '+91-40-24567812',
      status: 'open'
    },
    {
      _id: 'shelter_06',
      name: 'Apollo Emergency Care Unit - Disaster Outreach',
      type: 'hospital',
      location: {
        address: 'Road No 72, Jubilee Hills',
        city: 'Hyderabad',
        lat: 17.4278,
        lng: 78.4111
      },
      totalCapacity: 250,
      currentOccupancy: 190,
      availableBeds: 60,
      hasMedicalAid: true,
      hasFoodWater: true,
      contactPhone: '+91-40-23607777',
      status: 'open'
    }
  ];

  collections.shelters.clear();
  sampleShelters.forEach(s => collections.shelters.create(s));

  // 4. Seed Incident Reports
  const sampleReports = [
    {
      _id: 'report_01',
      title: 'Waterlogged Underpass - 4 Cars Submerged',
      disasterType: 'flood',
      severity: 'critical',
      description: 'Water depth is around 4.5 feet under the railway overbridge. Multiple commuters are perched on top of car roofs waiting for rescue.',
      location: {
        address: 'Malakpet Railway Bridge Underpass',
        lat: 17.3755,
        lng: 78.4920
      },
      imageUrl: 'https://images.unsplash.com/photo-1547683905-f686c993aae5?auto=format&fit=crop&w=600&q=80',
      reporterName: 'K. Sridhar (Local Resident)',
      reporterPhone: '+91-9848012345',
      victimsCount: 8,
      status: 'dispatched',
      dispatchedUnit: 'NDRF Boat Unit 4 & Fire Station 2',
      adminNotes: 'Inflatable dinghies deployed at 20:15 IST. Evacuation in progress.',
      createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString()
    },
    {
      _id: 'report_02',
      title: 'Old Building Wall Collapse onto Alleyway',
      disasterType: 'earthquake',
      severity: 'high',
      description: 'Portion of 2-storey brick wall collapsed following tremors. Power lines are dangling down into puddles. Road impassable.',
      location: {
        address: 'Lane 3, Charkaman, Charminar Area',
        lat: 17.3630,
        lng: 78.4730
      },
      imageUrl: 'https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?auto=format&fit=crop&w=600&q=80',
      reporterName: 'Mohammed Aslam',
      reporterPhone: '+91-9988776655',
      victimsCount: 2,
      status: 'pending',
      dispatchedUnit: '',
      adminNotes: 'Awaiting site verification by municipal engineer team.',
      createdAt: new Date(Date.now() - 1000 * 60 * 20).toISOString()
    },
    {
      _id: 'report_03',
      title: 'High Tension Electrical Wire Snapped',
      disasterType: 'cyclone',
      severity: 'critical',
      description: 'Severe gusts from cyclone snapped transmission line. Transformer sparking violently near school compound.',
      location: {
        address: 'Opposite Govt High School, Khairatabad',
        lat: 17.4110,
        lng: 78.4615
      },
      imageUrl: 'https://images.unsplash.com/photo-1516245834210-c4c142787335?auto=format&fit=crop&w=600&q=80',
      reporterName: 'P. Sunitha',
      reporterPhone: '+91-9440112233',
      victimsCount: 0,
      status: 'verified',
      dispatchedUnit: 'Disaster Power Grid Isolation Squad',
      adminNotes: 'Grid substation contacted to trip feeder line.',
      createdAt: new Date(Date.now() - 1000 * 60 * 10).toISOString()
    }
  ];

  collections.reports.clear();
  sampleReports.forEach(r => collections.reports.create(r));

  // 5. Seed Notification Audit Logs
  const sampleNotifications = [
    {
      _id: 'notif_01',
      channel: 'web_push',
      recipient: 'all_active_citizens',
      title: 'EMERGENCY ALERT: Cyclone "Varun" Landfall Warning',
      message: 'Take immediate shelter. Dial 112 for SOS.',
      severity: 'critical',
      timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString()
    },
    {
      _id: 'notif_02',
      channel: 'sms_gateway',
      recipient: 'Registered Citizens in Coastal Bay Region',
      title: '[NDMA ALERT] Severe Cyclone Advisory',
      message: 'Follow mandatory evacuation orders. Safe shelters activated.',
      timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
      status: 'SENT'
    },
    {
      _id: 'notif_03',
      channel: 'email_broadcast',
      recipient: 'registered_community@disaster-response.gov',
      title: 'URGENT: Flood Advisory in Musi Lowlands',
      message: 'Evacuate ground floors. Emergency relief centers are open.',
      timestamp: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
      status: 'DELIVERED'
    }
  ];

  collections.notifications.clear();
  sampleNotifications.forEach(n => collections.notifications.create(n));

  console.log('[Seed] Database seeded successfully!');
  console.log(`[Seed] 2 Users created (Officer: officer@disaster-response.gov / Officer123!, Citizen: citizen@example.com / Citizen123!)`);
  console.log(`[Seed] ${sampleAlerts.length} Disaster Alerts created`);
  console.log(`[Seed] ${sampleShelters.length} Shelters/Hospitals created`);
  console.log(`[Seed] ${sampleReports.length} Citizen SOS Reports created`);
}

if (require.main === module) {
  seedDatabase().then(() => process.exit(0));
}

module.exports = seedDatabase;
