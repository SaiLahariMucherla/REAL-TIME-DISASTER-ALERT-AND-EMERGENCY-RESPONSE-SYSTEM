const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const config = require('../config/config');
const reportController = require('../controllers/reportController');
const { protect, requireAuthority } = require('../middleware/authMiddleware');

// Setup multer disk storage for photo uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, config.UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, 'disaster-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed.'));
    }
  }
});

// Middleware to parse JSON location if sent as multipart form-data
const parseMultipartJson = (req, res, next) => {
  if (req.body && req.body.location && typeof req.body.location === 'string') {
    try {
      req.body.location = JSON.parse(req.body.location);
    } catch (e) {
      // Leave as string or let controller handle
    }
  }
  next();
};

router.get('/', reportController.getAllReports);
router.post('/', upload.single('image'), parseMultipartJson, reportController.createReport);
router.patch('/:id/status', protect, requireAuthority, reportController.updateReportStatus);
router.delete('/:id', protect, requireAuthority, reportController.deleteReport);

module.exports = router;
