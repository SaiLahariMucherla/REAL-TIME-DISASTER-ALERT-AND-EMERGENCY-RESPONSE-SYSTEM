import React, { useState } from 'react';
import {
  LifeBuoy,
  Hospital,
  MapPin,
  Phone,
  Search,
  Navigation,
  CheckCircle,
  AlertCircle,
  Users,
  Utensils,
  Stethoscope,
  Globe
} from 'lucide-react';
import { useLocation } from '../context/LocationContext';

function calcDist(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

const ShelterLocator = ({ shelters = [], onSelectForEvac }) => {
  const { currentLocation, setLocationModalOpen } = useLocation();
  const [filterType, setFilterType] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const enrichedShelters = shelters.map(s => {
    const dist = calcDist(currentLocation.lat, currentLocation.lng, s.location.lat, s.location.lng);
    return { ...s, distanceKm: dist };
  }).sort((a, b) => a.distanceKm - b.distanceKm);

  const filteredShelters = enrichedShelters.filter(s => {
    if (filterType !== 'all' && s.type !== filterType) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchesName = s.name.toLowerCase().includes(q);
      const matchesAddress = s.location.address.toLowerCase().includes(q);
      if (!matchesName && !matchesAddress) return false;
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-blue-400 text-xs font-mono font-bold uppercase tracking-wider mb-1">
            <LifeBuoy className="w-4 h-4" />
            Emergency Relief Infrastructure Grid
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Shelters & Emergency Medical Centers
          </h1>
          <p className="text-sm text-slate-400">
            Real-time bed availability tracking, medical aid stations, and verified safety havens.
          </p>
          <div className="flex items-center gap-2 mt-3 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-300 text-xs font-semibold">
              <Globe className="w-3.5 h-3.5" />
              Showing near: <span className="text-blue-200 font-bold ml-1">{currentLocation.name || currentLocation.city || 'Your Location'}</span>
            </div>
            <button
              onClick={() => setLocationModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition-colors"
            >
              Change Location
            </button>
          </div>
        </div>

        {/* Filter controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              filterType === 'all' ? 'bg-blue-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            All ({shelters.length})
          </button>
          <button
            onClick={() => setFilterType('shelter')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              filterType === 'shelter' ? 'bg-blue-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Safe Shelters ({shelters.filter(s => s.type === 'shelter').length})
          </button>
          <button
            onClick={() => setFilterType('hospital')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              filterType === 'hospital' ? 'bg-blue-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Hospitals ({shelters.filter(s => s.type === 'hospital').length})
          </button>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative max-w-md">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="Search shelter by name or street locality..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-slate-900 border border-slate-800 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
        />
      </div>

      {/* Shelters Cards Grid */}
      {filteredShelters.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center">
            <LifeBuoy className="w-8 h-8 text-slate-500" />
          </div>
          <div>
            <p className="text-slate-300 font-semibold">No shelters found near your location</p>
            <p className="text-slate-500 text-sm mt-1">
              Try changing your location or clearing the search filter.
            </p>
          </div>
          <button
            onClick={() => setLocationModalOpen(true)}
            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold transition-colors"
          >
            Change Location
          </button>
        </div>
      ) : (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredShelters.map((s) => {
          const isHospital = s.type === 'hospital';
          const occupancyPercent = Math.round((s.currentOccupancy / s.totalCapacity) * 100);
          const isFull = s.availableBeds <= 0;

          return (
            <div
              key={s._id || s.id}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl flex flex-col justify-between hover:border-slate-700 transition-all group"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className={`p-2 rounded-xl ${
                      isHospital ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                    }`}>
                      {isHospital ? <Hospital className="w-5 h-5" /> : <LifeBuoy className="w-5 h-5" />}
                    </div>
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono">
                        {isHospital ? 'Trauma Hospital' : 'Community Shelter'}
                      </span>
                      <h3 className="font-bold text-white text-sm leading-snug group-hover:text-blue-400 transition-colors">
                        {s.name}
                      </h3>
                    </div>
                  </div>
                </div>

                <div className="flex items-start justify-between gap-1.5 text-xs text-slate-400 mb-4">
                  <div className="flex items-start gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                    <span>{s.location.address}</span>
                  </div>
                  {s.distanceKm !== undefined && (
                    <span className="shrink-0 px-2 py-0.5 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20 font-mono text-[11px] font-bold">
                      {s.distanceKm} km away
                    </span>
                  )}
                </div>

                {/* Bed Availability Progress Meter */}
                <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800/80 mb-4 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400 font-medium">Beds Remaining:</span>
                    <span className={`font-mono font-bold ${
                      isFull ? 'text-red-400' : s.availableBeds < 100 ? 'text-amber-400' : 'text-emerald-400'
                    }`}>
                      {s.availableBeds} / {s.totalCapacity}
                    </span>
                  </div>

                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 ${
                        occupancyPercent > 85 ? 'bg-red-500' : occupancyPercent > 60 ? 'bg-amber-500' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(100, occupancyPercent)}%` }}
                    />
                  </div>
                  <div className="text-[10px] text-slate-500 flex justify-between font-mono">
                    <span>{occupancyPercent}% Occupied</span>
                    <span>Status: {isFull ? 'FULL' : 'OPEN'}</span>
                  </div>
                </div>

                {/* Badges */}
                <div className="flex flex-wrap gap-2 text-[11px] mb-4">
                  {s.hasMedicalAid && (
                    <span className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
                      <Stethoscope className="w-3 h-3" /> Medical Aid
                    </span>
                  )}
                  {s.hasFoodWater && (
                    <span className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20 font-medium">
                      <Utensils className="w-3 h-3" /> Food & Water
                    </span>
                  )}
                  <span className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-slate-800 text-slate-300 font-mono">
                    <Users className="w-3 h-3" /> Max {s.totalCapacity}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-800 flex items-center gap-2">
                <a
                  href={`tel:${s.contactPhone}`}
                  className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Phone className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Call {s.contactPhone}</span>
                </a>

                {onSelectForEvac && (
                  <button
                    onClick={() => onSelectForEvac(s)}
                    className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-xs font-bold text-white shadow-md shadow-emerald-600/20 flex items-center justify-center gap-1.5 transition-all"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>Evac Route</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
      )}
    </div>
  );
};

export default ShelterLocator;
