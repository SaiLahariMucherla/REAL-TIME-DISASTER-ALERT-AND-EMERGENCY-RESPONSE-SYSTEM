const mongoose = require('mongoose');
const config = require('./config');

let isMongoConnected = false;

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(config.MONGODB_URI, {
      serverSelectionTimeoutMS: 2000
    });
    isMongoConnected = true;
    console.log(`[Database] MongoDB Connected: ${conn.connection.host}`);
    return true;
  } catch (error) {
    isMongoConnected = false;
    console.warn(`[Database] MongoDB not reachable at ${config.MONGODB_URI}.`);
    console.log(`[Database] Using High-Performance Embedded Persistent JSON Database Layer.`);
    return false;
  }
};

const getStatus = () => ({
  mode: isMongoConnected ? 'MongoDB (Mongoose)' : 'Embedded Persistent Store',
  uri: config.MONGODB_URI,
  isConnected: true
});

module.exports = {
  connectDB,
  getStatus,
  getIsMongoConnected: () => isMongoConnected
};
