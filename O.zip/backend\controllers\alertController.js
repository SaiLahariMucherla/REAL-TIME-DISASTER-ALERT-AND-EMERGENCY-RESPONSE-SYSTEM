const { Alert } = require('../models/dataRepository');
const notificationService = require('../services/notificationService');
const externalFeedService = require('../services/externalFeedService');

function calcDistanceKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

function generateLocalAlert(cityName, lat, lng) {
  const cleanCity = cityName ? cityName.split(',')[0].trim() : 'Local Area';
  return {
    title: `FLASH FLOOD & INUNDATION: Low-Lying River Basin Warning (${cleanCity})`,
    type: 'flood',
    severity: 'critical',
    description: `Heavy torrential precipitation of 145mm has triggered rapid waterlogging across low-lying underpasses and arterial roads in ${cleanCity}. Evacuate ground levels immediately.`,
    location: {
      area: `${cleanCity} Lowlands & River Corridor`,
      city: cleanCity,
      lat: Math.round((lat + 0.005) * 10000) / 10000,
      lng: Math.round((lng + 0.006) * 10000) / 10000,
      radiusKm: 6
    },
    instructions: [
      'Avoid low-lying underpasses and bridge approaches',
      'Move to designated elevated shelters immediately',
      'Turn off residential main circuit breakers',
      'Dial 112 or 1078 for rescue boats'
    ],
    source: 'State Disaster Management Cell',
    active: true,
    issuedAt: new Date().toISOString()
  };
}

// Get all active alerts
exports.getAllAlerts = async (req, res) => {
  try {
    const { type, severity, active, userLat, userLng, cityName } = req.query;
    let alerts = await Alert.find();

    if (userLat && userLng) {
      const uLat = parseFloat(userLat);
      const uLng = parseFloat(userLng);
      const nearbyAlert = alerts.find(a => a.active && calcDistanceKm(uLat, uLng, a.location.lat, a.location.lng) <= 40);

      // If no active hazard nearby in this city, auto-provision local hazard
      if (!nearbyAlert) {
        const localAlert = generateLocalAlert(cityName, uLat, uLng);
        const created = await Alert.create(localAlert);
        alerts.unshift(created);
      }
    }

    if (type && type !== 'all') {
      alerts = alerts.filter(a => a.type === type.toLowerCase());
    }
    if (severity && severity !== 'all') {
      alerts = alerts.filter(a => a.severity === severity.toLowerCase());
    }
    if (active !== undefined) {
      const isActive = active === 'true';
      alerts = alerts.filter(a => a.active === isActive);
    }

    return res.json({
      success: true,
      count: alerts.length,
      alerts
    });
  } catch (error) {
    console.error('[alertController.getAllAlerts]', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve alerts' });
  }
};

// Get single alert
exports.getAlertById = async (req, res) => {
  try {
    const alert = await Alert.findById(req.params.id);
    if (!alert) {
      return res.status(404).json({ success: false, message: 'Alert not found' });
    }
    return res.json({ success: true, alert });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Error retrieving alert' });
  }
};

// Create new disaster alert (Authority only)
exports.createAlert = async (req, res) => {
  try {
    const { title, type, severity, description, location, instructions, expiresAt } = req.body;

    if (!title || !type || !description || !location || !location.area || !location.lat || !location.lng) {
      return res.status(400).json({
        success: false,
        message: 'Please provide title, disaster type, description, area name, latitude, and longitude.'
      });
    }

    const alertDoc = await Alert.create({
      title,
      type: type.toLowerCase(),
      severity: severity || 'high',
      description,
      location: {
        area: location.area,
        city: location.city || location.area,
        lat: parseFloat(location.lat),
        lng: parseFloat(location.lng),
        radiusKm: location.radiusKm ? parseFloat(location.radiusKm) : 15
      },
      instructions: instructions || [
        'Move to higher ground if flood warning is issued',
        'Avoid coastal zones and low-lying regions',
        'Keep emergency supplies and batteries ready',
        'Follow instructions from local disaster authorities'
      ],
      source: req.user ? `${req.user.name} (${req.user.role.toUpperCase()})` : 'Disaster Management Authority',
      active: true,
      issuedAt: new Date().toISOString(),
      expiresAt: expiresAt || null
    });

    // Dispatch real-time notification & Socket.io broadcast
    await notificationService.broadcastDisasterAlert(alertDoc);

    return res.status(201).json({
      success: true,
      message: 'Disaster warning broadcasted successfully',
      alert: alertDoc
    });
  } catch (error) {
    console.error('[alertController.createAlert]', error);
    return res.status(500).json({ success: false, message: 'Failed to broadcast disaster alert' });
  }
};

// Update alert status (deactivate, resolve, or edit)
exports.updateAlert = async (req, res) => {
  try {
    const updated = await Alert.findByIdAndUpdate(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ success: false, message: 'Alert not found' });
    }
    return res.json({ success: true, message: 'Alert updated', alert: updated });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Failed to update alert' });
  }
};

// Delete alert
exports.deleteAlert = async (req, res) => {
  try {
    const deleted = await Alert.findByIdAndDelete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: 'Alert not found' });
    }
    return res.json({ success: true, message: 'Alert deleted successfully' });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Failed to delete alert' });
  }
};

// Get live external feeds (USGS Earthquake & Open-Meteo Weather)
exports.getLiveFeeds = async (req, res) => {
  try {
    const lat = req.query.lat ? parseFloat(req.query.lat) : 17.385;
    const lng = req.query.lng ? parseFloat(req.query.lng) : 78.486;

    const [earthquakes, weather] = await Promise.all([
      externalFeedService.getLiveEarthquakes(),
      externalFeedService.getLiveWeather(lat, lng)
    ]);

    return res.json({
      success: true,
      data: {
        earthquakes,
        weather,
        fetchedAt: new Date().toISOString()
      }
    });
  } catch (error) {
    console.error('[alertController.getLiveFeeds]', error);
    return res.status(500).json({ success: false, message: 'Failed to fetch live feeds' });
  }
};
