import React, { useState, useEffect } from 'react';
import {
  MapContainer,
  TileLayer,
  Marker,
  Polyline,
  Circle,
  useMap
} from 'react-leaflet';
import L from 'leaflet';
import {
  Navigation,
  ShieldCheck,
  AlertTriangle,
  Clock,
  Car,
  Footprints,
  ChevronRight,
  ArrowRight,
  CheckCircle,
  Sparkles,
  Globe,
  MapPin
} from 'lucide-react';
import { useLocation } from '../context/LocationContext';

function ChangeNavView({ bounds }) {
  const map = useMap();
  useEffect(() => {
    if (bounds && bounds.length > 0) {
      map.fitBounds(bounds, { padding: [40, 40] });
    }
  }, [bounds, map]);
  return null;
}

// Marker icons
const startIcon = L.divIcon({
  className: 'start-marker',
  html: `<div style="background-color: #3b82f6; width: 28px; height: 28px; border-radius: 50%; border: 3px solid white; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 10px #3b82f6; color: white; font-weight: bold; font-size: 12px;">YOU</div>`,
  iconSize: [28, 28],
  iconAnchor: [14, 14]
});

const destIcon = L.divIcon({
  className: 'dest-marker',
  html: `<div style="background-color: #10b981; width: 28px; height: 28px; border-radius: 50%; border: 3px solid white; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 10px #10b981; color: white; font-weight: bold; font-size: 14px;">🏥</div>`,
  iconSize: [28, 28],
  iconAnchor: [14, 14]
});

// Haversine distance
function calcDist(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

const EvacuationNav = ({ shelters = [], alerts = [], selectedShelter = null }) => {
  const { currentLocation, setLocationModalOpen } = useLocation();
  const [userCoords, setUserCoords] = useState({ lat: currentLocation.lat, lng: currentLocation.lng });
  const [targetShelter, setTargetShelter] = useState(selectedShelter || shelters[0] || null);
  const [routeWaypoints, setRouteWaypoints] = useState([]);
  const [routeStats, setRouteStats] = useState({ distance: 0, walkTime: 0, driveTime: 0, isDetour: false });
  const [directions, setDirections] = useState([]);

  // Sync when currentLocation changes
  useEffect(() => {
    setUserCoords({ lat: currentLocation.lat, lng: currentLocation.lng });
  }, [currentLocation]);

  useEffect(() => {
    if (selectedShelter) {
      setTargetShelter(selectedShelter);
    } else if (!targetShelter && shelters.length > 0) {
      setTargetShelter(shelters[0]);
    }
  }, [selectedShelter, shelters]);

  const [routingMode, setRoutingMode] = useState('shortest'); // 'shortest' or 'safest'

  // Compute Evacuation Route
  useEffect(() => {
    if (!targetShelter) return;

    const start = [userCoords.lat, userCoords.lng];
    const end = [targetShelter.location.lat, targetShelter.location.lng];
    const baseDistance = calcDist(start[0], start[1], end[0], end[1]);

    // Check if line intersects any active critical hazard zone
    const criticalHazards = alerts.filter(a => a.active && (a.severity === 'critical' || a.severity === 'high'));
    let hazardInPath = false;
    let detourOffset = { lat: 0, lng: 0 };

    criticalHazards.forEach(hazard => {
      const hDist = calcDist((start[0] + end[0]) / 2, (start[1] + end[1]) / 2, hazard.location.lat, hazard.location.lng);
      if (hDist < (hazard.location.radiusKm || 10)) {
        hazardInPath = true;
        detourOffset = {
          lat: hazard.location.lat + (hazard.location.lat > start[0] ? 0.045 : -0.045),
          lng: hazard.location.lng + (hazard.location.lng > start[1] ? 0.055 : -0.055)
        };
      }
    });

    let waypoints = [];
    let calculatedDist = baseDistance;
    const isDetourActive = routingMode === 'safest' && hazardInPath;

    if (isDetourActive) {
      // Skirting around hazard zone
      waypoints = [
        start,
        [start[0] + (detourOffset.lat - start[0]) * 0.5, start[1] + (detourOffset.lng - start[1]) * 0.4],
        [detourOffset.lat, detourOffset.lng],
        [detourOffset.lat + (end[0] - detourOffset.lat) * 0.6, detourOffset.lng + (end[1] - detourOffset.lng) * 0.7],
        end
      ];
      calculatedDist = Math.round((baseDistance * 1.35) * 10) / 10;
    } else {
      // Shortest Direct Corridor route (straightforward path)
      const latDiff = end[0] - start[0];
      const lngDiff = end[1] - start[1];
      waypoints = [
        start,
        [start[0] + latDiff * 0.25, start[1] + lngDiff * 0.25],
        [start[0] + latDiff * 0.50, start[1] + lngDiff * 0.50],
        [start[0] + latDiff * 0.75, start[1] + lngDiff * 0.75],
        end
      ];
      calculatedDist = Math.round(baseDistance * 10) / 10;
    }

    const walkMinutes = Math.max(1, Math.round(calculatedDist * 12)); // ~5 km/h walking
    const driveMinutes = Math.max(1, Math.round(calculatedDist * 2.2) + 2); // ~30 km/h city driving

    setRouteWaypoints(waypoints);
    setRouteStats({
      distance: calculatedDist,
      walkTime: walkMinutes,
      driveTime: driveMinutes,
      isDetour: isDetourActive,
      hazardInPath
    });

    // Generate Turn-by-Turn Steps
    setDirections([
      {
        step: 1,
        instruction: 'Depart immediate location onto primary connecting avenue toward shelter.',
        distance: `${(calculatedDist * 0.25).toFixed(1)} km`,
        action: 'START'
      },
      {
        step: 2,
        instruction: isDetourActive
          ? 'CAUTION DETOUR: Turn north-east along bypass road to circle around hazard perimeter.'
          : (hazardInPath ? 'NOTICE: Direct fastest corridor active. Exercise caution near monitored zone.' : 'Continue directly straight on designated evacuation roadway.'),
        distance: `${(calculatedDist * 0.4).toFixed(1)} km`,
        action: isDetourActive ? 'DETOUR' : 'CONTINUE'
      },
      {
        step: 3,
        instruction: 'Approach local sector checkpoint; follow emergency relief route markers.',
        distance: `${(calculatedDist * 0.25).toFixed(1)} km`,
        action: 'CHECKPOINT'
      },
      {
        step: 4,
        instruction: `Arrive at destination: ${targetShelter.name}. Safe haven check-in station ahead.`,
        distance: `${(calculatedDist * 0.1).toFixed(1)} km`,
        action: 'ARRIVE'
      }
    ]);
  }, [userCoords, targetShelter, alerts, routingMode]);

  // Handle Find Closest Shelter
  const handleFindNearest = () => {
    if (!shelters.length) return;
    let closest = shelters[0];
    let minDist = 999999;
    shelters.forEach(s => {
      const d = calcDist(userCoords.lat, userCoords.lng, s.location.lat, s.location.lng);
      if (d < minDist) {
        minDist = d;
        closest = s;
      }
    });
    setTargetShelter(closest);
  };

  const mapBounds = routeWaypoints.length > 0 ? routeWaypoints : [[userCoords.lat, userCoords.lng]];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-mono font-bold uppercase tracking-wider mb-1">
            <ShieldCheck className="w-4 h-4" />
            AI Safe Corridor Navigation
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Safe Evacuation Route Guidance
          </h1>
          <p className="text-sm text-slate-400">
            Real-time hazard perimeter avoidance calculating the safest path to medical havens & shelters.
          </p>
        </div>

        <button
          onClick={handleFindNearest}
          className="self-start md:self-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-emerald-600/20 active:scale-95 transition-all"
        >
          <Sparkles className="w-4 h-4" />
          Auto-Route to Nearest Safe Shelter
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: Route Controls & Turn-by-Turn Steps */}
        <div className="lg:col-span-5 space-y-4">
          {/* Starting Origin Location Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono font-bold uppercase text-blue-400 block mb-0.5">
                Starting Evacuation Point:
              </span>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <span className="truncate max-w-[200px]">{currentLocation.name}</span>
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                [{currentLocation.lat.toFixed(4)}, {currentLocation.lng.toFixed(4)}]
              </div>
            </div>
            <button
              onClick={() => setLocationModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/40 text-xs font-semibold flex items-center gap-1 transition-all"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Change</span>
            </button>
          </div>

          {/* Target Shelter Selector */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
              Select Destination Shelter / Medical Camp
            </label>
            <select
              value={targetShelter?._id || targetShelter?.id || ''}
              onChange={(e) => {
                const found = shelters.find(s => (s._id || s.id) === e.target.value);
                if (found) setTargetShelter(found);
              }}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
            >
              {shelters.map(s => (
                <option key={s._id || s.id} value={s._id || s.id}>
                  {s.name} ({s.availableBeds} beds available)
                </option>
              ))}
            </select>

            {/* Routing Mode Toggle (Shortest Route vs Safe Detour) */}
            <div className="mt-4 pt-3 border-t border-slate-800">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                Routing Mode Strategy:
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setRoutingMode('shortest')}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                    routingMode === 'shortest'
                      ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30 ring-1 ring-emerald-400'
                      : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>⚡ Shortest Direct Route</span>
                </button>
                <button
                  type="button"
                  onClick={() => setRoutingMode('safest')}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                    routingMode === 'safest'
                      ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/30 ring-1 ring-amber-400'
                      : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>🛡️ Perimeter Detour</span>
                </button>
              </div>
            </div>

            {/* Quick Metrics Cards */}
            <div className="grid grid-cols-3 gap-2 mt-4">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
                <div className="text-[10px] font-mono text-slate-400 uppercase">Distance</div>
                <div className="text-lg font-black text-white mt-0.5">{routeStats.distance} <span className="text-xs font-normal text-slate-400">km</span></div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
                <div className="text-[10px] font-mono text-slate-400 uppercase flex items-center justify-center gap-1">
                  <Car className="w-3 h-3 text-emerald-400" /> Vehicle
                </div>
                <div className="text-lg font-black text-emerald-400 mt-0.5">{routeStats.driveTime} <span className="text-xs font-normal text-slate-400">min</span></div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
                <div className="text-[10px] font-mono text-slate-400 uppercase flex items-center justify-center gap-1">
                  <Footprints className="w-3 h-3 text-blue-400" /> Walk
                </div>
                <div className="text-lg font-black text-blue-400 mt-0.5">{routeStats.walkTime} <span className="text-xs font-normal text-slate-400">min</span></div>
              </div>
            </div>

            {/* Safety Detour Notice */}
            {routeStats.isDetour ? (
              <div className="mt-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
                <div>
                  <div className="font-bold">Active Danger Zone Evaded</div>
                  <div className="text-amber-200/80 mt-0.5 text-[11px]">
                    Direct route passes through flood inundation / seismic fault. Safe detour applied to avoid high-risk sectors.
                  </div>
                </div>
              </div>
            ) : (
              <div className="mt-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>Green Corridor Verified: Direct transit path is clear of active hazards.</span>
              </div>
            )}
          </div>

          {/* Turn-by-turn guidance list */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h3 className="font-bold text-white text-sm flex items-center gap-2 mb-3">
              <Navigation className="w-4 h-4 text-emerald-400" />
              Turn-by-Turn Evacuation Instructions
            </h3>

            <div className="space-y-3">
              {directions.map((d) => (
                <div key={d.step} className="flex items-start gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                  <div className="w-6 h-6 rounded-full bg-slate-800 text-emerald-400 text-xs font-bold font-mono flex items-center justify-center shrink-0">
                    {d.step}
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-slate-200 leading-relaxed font-medium">{d.instruction}</p>
                    <div className="text-[10px] text-slate-500 mt-1 font-mono">Segment: {d.distance}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side: Visual Route Map */}
        <div className="lg:col-span-7 h-[550px] rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl relative">
          <MapContainer
            center={[userCoords.lat, userCoords.lng]}
            zoom={13}
            scrollWheelZoom={true}
            className="w-full h-full"
          >
            <ChangeNavView bounds={mapBounds} />

            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />

            {/* Start Marker */}
            <Marker position={[userCoords.lat, userCoords.lng]} icon={startIcon} />

            {/* Destination Marker */}
            {targetShelter && (
              <Marker
                position={[targetShelter.location.lat, targetShelter.location.lng]}
                icon={destIcon}
              />
            )}

            {/* Active Hazard Danger Zones on Evacuation Map */}
            {alerts.filter(a => a.active).map(a => (
              <Circle
                key={a._id || a.id}
                center={[a.location.lat, a.location.lng]}
                radius={(a.location.radiusKm || 12) * 1000}
                pathOptions={{
                  color: a.severity === 'critical' ? '#ef4444' : '#f97316',
                  fillColor: a.severity === 'critical' ? '#ef4444' : '#f97316',
                  fillOpacity: 0.2,
                  dashArray: '5, 10'
                }}
              />
            ))}

            {/* Safe Route Polyline (Green Glowing Line) */}
            {routeWaypoints.length > 0 && (
              <Polyline
                positions={routeWaypoints}
                pathOptions={{
                  color: '#10b981',
                  weight: 6,
                  opacity: 0.9,
                  lineCap: 'round',
                  lineJoin: 'round'
                }}
              />
            )}
          </MapContainer>

          {/* Floating Map Overlay Banner */}
          <div className="absolute bottom-4 right-4 z-[400] bg-slate-900/95 backdrop-blur-md px-3.5 py-2 rounded-xl border border-slate-800 shadow-xl text-xs flex items-center gap-3">
            <span className="flex items-center gap-1.5 text-slate-300">
              <span className="w-3 h-1 bg-emerald-500 rounded-full" /> Recommended Safe Path
            </span>
            <span className="flex items-center gap-1.5 text-slate-300">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500/50 border border-red-500" /> Danger Zone
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EvacuationNav;
