const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const path = require('path');
const config = require('./config/config');
const { connectDB } = require('./config/db');
const notificationService = require('./services/notificationService');
const seedDatabase = require('./seeds/seedData');
const { collections } = require('./services/storageAdapter');

// Routes
const authRoutes = require('./routes/authRoutes');
const alertRoutes = require('./routes/alertRoutes');
const reportRoutes = require('./routes/reportRoutes');
const shelterRoutes = require('./routes/shelterRoutes');
const statsRoutes = require('./routes/statsRoutes');

const app = express();
const server = http.createServer(app);

// Setup Socket.io
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE']
  }
});

// Pass Socket.io instance to NotificationService
notificationService.setSocketIO(io);

// Middleware
app.use(cors());
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));

// Static file hosting for incident photo uploads
app.use('/uploads', express.static(config.UPLOADS_DIR));

// API Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    service: 'Real-Time Disaster Alert and Emergency Response System',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Mount API routes
app.use('/api/auth', authRoutes);
app.use('/api/alerts', alertRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/shelters', shelterRoutes);
app.use('/api/stats', statsRoutes);

// Socket.io Real-Time Connection
io.on('connection', (socket) => {
  console.log(`[Socket.io] Client connected: ${socket.id}`);

  // Join designated channel
  socket.on('join_room', (room) => {
    socket.join(room);
    console.log(`[Socket.io] Client ${socket.id} joined channel: ${room}`);
  });

  // Client sent quick panic beacon
  socket.on('citizen_panic_beacon', (data) => {
    console.log('[Socket.io] PANIC BEACON RECEIVED:', data);
    io.emit('emergency_beacon_alert', {
      timestamp: new Date().toISOString(),
      ...data
    });
  });

  socket.on('disconnect', () => {
    console.log(`[Socket.io] Client disconnected: ${socket.id}`);
  });
});

// Serve Built Frontend (SPA) if dist exists
const frontendDistPath = path.join(__dirname, '../frontend/dist');
const fs = require('fs');
if (fs.existsSync(frontendDistPath)) {
  app.use(express.static(frontendDistPath));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api') || req.path.startsWith('/uploads') || req.path.startsWith('/socket.io')) {
      return next();
    }
    res.sendFile(path.join(frontendDistPath, 'index.html'));
  });
}

// Global error handler
app.use((err, req, res, next) => {
  console.error('[Unhandled Error]', err.stack || err.message);
  res.status(500).json({
    success: false,
    message: err.message || 'Internal Server Error'
  });
});

// Boot Server
const PORT = config.PORT;

async function startServer() {
  await connectDB();

  // If initial seed is empty, run seed data automatically
  if (collections.users.find().length === 0 || collections.alerts.find().length === 0) {
    console.log('[Startup] Empty database detected. Running automatic initial data seed...');
    await seedDatabase();
  }

  server.listen(PORT, () => {
    console.log(`================================================================`);
    console.log(`  EMERGENCY RESPONSE BACKEND ENGINE ONLINE`);
    console.log(`  Port: http://localhost:${PORT}`);
    console.log(`  Health Check: http://localhost:${PORT}/api/health`);
    console.log(`  WebSocket (Socket.io) Active & Ready`);
    console.log(`================================================================`);
  });
}

startServer();
