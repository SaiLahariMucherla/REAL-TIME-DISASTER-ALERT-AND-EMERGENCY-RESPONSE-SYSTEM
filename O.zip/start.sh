#!/usr/bin/env bash
echo "==================================================================="
echo "  ResQ-Alert: Real-Time Disaster Alert and Emergency Response System"
echo "==================================================================="

cd backend || exit
if [ ! -d "node_modules" ]; then
  echo "Installing backend dependencies..."
  npm install
fi

echo "Starting Unified Emergency Response Server (Port 5000)..."
echo "Access URL: http://localhost:5000"
node server.js
