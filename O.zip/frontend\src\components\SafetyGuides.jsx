import React, { useState } from 'react';
import {
  BookOpen,
  Waves,
  Wind,
  Activity,
  Flame,
  Mountain,
  HeartPulse,
  CheckSquare,
  Square,
  ShieldCheck,
  PhoneCall,
  Download
} from 'lucide-react';

const disasterGuides = {
  flood: {
    title: 'Flash Flood & River Inundation Survival Protocol',
    icon: '🌊',
    before: [
      'Elevate essential appliances, electrical panels, and valuable documentation above potential flood lines.',
      'Clear stormwater runoff drains and gutters around your residential perimeter.',
      'Prepare emergency water containers (at least 4 liters per person per day for 3 days).'
    ],
    during: [
      'NEVER attempt to walk or drive through flowing water. Just 15 cm of moving water can knock an adult down.',
      'If trapped inside a building, move to upper floors or roof. Do NOT climb into a closed attic without an exit.',
      'Switch off master electrical breaker and LPG gas cylinder valves immediately.'
    ],
    after: [
      'Avoid standing floodwater as it may carry sewage, toxic runoff, chemical spills, or snapped electrical lines.',
      'Boil all drinking water for at least 1 minute before consuming or cooking.',
      'Photograph all property and structural damage for disaster relief and insurance verification.'
    ]
  },
  cyclone: {
    title: 'Severe Cyclonic Storm & Squall Survival Protocol',
    icon: '🌀',
    before: [
      'Trim decaying branches, inspect roof sheeting, and board up large glass windows.',
      'Secure outdoor furniture, metal sheets, and loose rooftop water tanks.',
      'Charge mobile phones, power banks, and ensure battery-operated emergency transceivers are working.'
    ],
    during: [
      'Remain indoors in the strongest central room or hallway without windows.',
      'Beware the "Eye of the Storm": a sudden calm does not mean the cyclone is over; winds will resume in reverse.',
      'Unplug electrical appliances to protect against extreme lightning surges.'
    ],
    after: [
      'Stay inside until official "All Clear" announcement is issued by disaster authorities.',
      'Beware of live dangling electric cables; report downed lines immediately via ResQ-Alert SOS.',
      'Do not venture near beaches or harbor seawalls due to dangerous delayed storm swells.'
    ]
  },
  earthquake: {
    title: 'Seismic Shock & Earthquake Response Protocol',
    icon: '⚡',
    before: [
      'Fasten tall bookcases, cabinets, and water heaters firmly to structural wall studs.',
      'Store breakable items and heavy objects on low shelves with latching cabinet doors.',
      'Identify safe spots in every room: under sturdy desks, interior load-bearing walls.'
    ],
    during: [
      'DROP to the floor, take COVER under a sturdy table, and HOLD ON until tremors stop.',
      'If indoors, stay indoors. Do NOT run outside during shaking where falling bricks and glass are lethal.',
      'If outdoors, move to an open area away from electrical pylons, facades, billboards, and bridges.'
    ],
    after: [
      'Expect aftershocks. Be prepared to Drop, Cover, and Hold again.',
      'Check for gas leaks: if you smell sulfur or gas, evacuate immediately and leave doors open.',
      'Do not use elevators under any circumstances.'
    ]
  },
  wildfire: {
    title: 'Brush Fire & Wildfire Evacuation Protocol',
    icon: '🔥',
    before: [
      'Maintain a 30-foot defensible perimeter around homes clear of dry brush and flammable leaves.',
      'Store fire extinguishers in easily accessible areas and inspect pressure gauges.',
      'Plan at least two evacuation road routes out of your neighborhood.'
    ],
    during: [
      'Wear N95 masks, cotton/wool long-sleeve clothing, and goggles to protect eyes and lungs from smoke.',
      'Close all windows, exterior doors, attic vents, and fireplace flues to prevent flying ember ingress.',
      'Evacuate as soon as advisory is issued. Roads can become clogged with smoke and fire engines rapidly.'
    ],
    after: [
      'Do not enter burnt areas until designated safe by firefighters; hidden hot spots can flare up.',
      'Check roofs and attic spaces for smoldering sparks or embers.'
    ]
  }
};

const SafetyGuides = () => {
  const [selectedDisaster, setSelectedDisaster] = useState('flood');
  const [checklist, setChecklist] = useState({
    water: true,
    food: true,
    firstaid: false,
    flashlight: false,
    documents: false,
    radio: false,
    medicines: false,
    cash: false
  });

  const toggleCheck = (item) => {
    setChecklist(prev => ({ ...prev, [item]: !prev[item] }));
  };

  const guide = disasterGuides[selectedDisaster];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-purple-400 text-xs font-mono font-bold uppercase tracking-wider mb-1">
            <BookOpen className="w-4 h-4" />
            Standard Operating Survival Guidelines
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Disaster Preparedness & Survival Playbook
          </h1>
          <p className="text-sm text-slate-400">
            Official NDMA & Red Cross safety procedures, phased action steps, and 72-hour survival checklist.
          </p>
        </div>
      </div>

      {/* Disaster Category Tabs */}
      <div className="flex flex-wrap gap-2">
        {Object.entries(disasterGuides).map(([key, item]) => (
          <button
            key={key}
            onClick={() => setSelectedDisaster(key)}
            className={`px-4 py-2.5 rounded-2xl text-xs font-bold flex items-center gap-2 transition-all ${
              selectedDisaster === key
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <span>{item.icon}</span>
            <span className="capitalize">{key}</span>
          </button>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Phased Action Guide (8 cols) */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{guide.icon}</span>
            <div>
              <h2 className="text-xl font-bold text-white">{guide.title}</h2>
              <p className="text-xs text-slate-400">Standard disaster life-safety recommendations</p>
            </div>
          </div>

          <div className="space-y-6">
            {/* Phased Steps */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <h3 className="text-xs font-bold font-mono uppercase text-blue-400 mb-2.5 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-500" /> Phase 1: Pre-Disaster Preparedness (Before)
              </h3>
              <ul className="space-y-2 text-xs text-slate-300">
                {guide.before.map((step, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-blue-400 font-bold shrink-0">•</span>
                    <span>{step}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-red-900/40 bg-red-950/10">
              <h3 className="text-xs font-bold font-mono uppercase text-red-400 mb-2.5 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" /> Phase 2: Active Impact Response (During)
              </h3>
              <ul className="space-y-2 text-xs text-slate-300">
                {guide.during.map((step, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-red-400 font-bold shrink-0">•</span>
                    <span>{step}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
              <h3 className="text-xs font-bold font-mono uppercase text-emerald-400 mb-2.5 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500" /> Phase 3: Post-Impact Recovery & Evacuation (After)
              </h3>
              <ul className="space-y-2 text-xs text-slate-300">
                {guide.after.map((step, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold shrink-0">•</span>
                    <span>{step}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* 72-Hour Survival Go-Bag Interactive Checklist (4 cols) */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <h3 className="font-bold text-white text-base">72-Hour Go-Bag Checklist</h3>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              OFFLINE READY
            </span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Essential grab-and-go kit items to sustain one individual for 3 full days away from municipal power & water.
          </p>

          <div className="space-y-2.5 text-xs">
            {[
              { id: 'water', label: '3-Day Sealed Water (4L / person / day)' },
              { id: 'food', label: 'Non-Perishable Canned Food / Energy Bars' },
              { id: 'firstaid', label: 'Comprehensive First-Aid Kit & Antiseptics' },
              { id: 'flashlight', label: 'High-Lumen Flashlight + Extra Batteries' },
              { id: 'documents', label: 'Waterproof Bag with Passports & IDs' },
              { id: 'radio', label: 'Hand-Cranked or Solar Emergency AM/FM Radio' },
              { id: 'medicines', label: 'Prescription Medications (7-day supply)' },
              { id: 'cash', label: 'Emergency Cash in Small Denominations' }
            ].map(item => (
              <div
                key={item.id}
                onClick={() => toggleCheck(item.id)}
                className={`p-3 rounded-xl border cursor-pointer flex items-center justify-between transition-all ${
                  checklist[item.id]
                    ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-300 font-medium'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <span>{item.label}</span>
                {checklist[item.id] ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 ml-2" />
                ) : (
                  <Square className="w-4 h-4 text-slate-600 shrink-0 ml-2" />
                )}
              </div>
            ))}
          </div>

          {/* Quick Hotline Helper Box */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs space-y-2">
            <div className="font-bold text-white flex items-center gap-1.5">
              <PhoneCall className="w-3.5 h-3.5 text-red-500" />
              Emergency Toll-Free Lines
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
              <div className="bg-slate-900 p-2 rounded-lg text-slate-300">
                All-in-one: <strong className="text-white">112</strong>
              </div>
              <div className="bg-slate-900 p-2 rounded-lg text-slate-300">
                NDRF Cell: <strong className="text-white">1078</strong>
              </div>
              <div className="bg-slate-900 p-2 rounded-lg text-slate-300">
                Ambulance: <strong className="text-white">108</strong>
              </div>
              <div className="bg-slate-900 p-2 rounded-lg text-slate-300">
                Fire Service: <strong className="text-white">101</strong>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SafetyGuides;
