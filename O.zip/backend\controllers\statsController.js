const { Alert, IncidentReport, Shelter, NotificationLog, User } = require('../models/dataRepository');
const db = require('../config/db');

exports.getDashboardStats = async (req, res) => {
  try {
    const alerts = await Alert.find();
    const reports = await IncidentReport.find();
    const shelters = await Shelter.find();
    const notifications = await NotificationLog.find();
    const users = await User.find();

    const activeAlerts = alerts.filter(a => a.active);
    const criticalAlerts = activeAlerts.filter(a => a.severity === 'critical');

    const pendingReports = reports.filter(r => r.status === 'pending');
    const dispatchedReports = reports.filter(r => r.status === 'dispatched');
    const resolvedReports = reports.filter(r => r.status === 'resolved');

    let totalCapacity = 0;
    let totalAvailableBeds = 0;
    shelters.forEach(s => {
      totalCapacity += (s.totalCapacity || 0);
      totalAvailableBeds += (s.availableBeds || 0);
    });

    const recentNotifications = notifications.slice(0, 15);

    return res.json({
      success: true,
      stats: {
        totalAlerts: alerts.length,
        activeAlertsCount: activeAlerts.length,
        criticalAlertsCount: criticalAlerts.length,
        totalReports: reports.length,
        pendingReportsCount: pendingReports.length,
        dispatchedReportsCount: dispatchedReports.length,
        resolvedReportsCount: resolvedReports.length,
        totalSheltersCount: shelters.length,
        totalCapacity,
        totalAvailableBeds,
        totalUsers: users.length,
        dbStatus: db.getStatus()
      },
      recentNotifications
    });
  } catch (error) {
    console.error('[statsController.getDashboardStats]', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve stats' });
  }
};
