# Real-Time Disaster Alert and Emergency Response System (ResQ-Alert)

> **Web Technologies Capstone Project**  
> **Student Author:** Sai Lahari  
> **Domain:** Full-Stack Web Technologies, Distributed Real-Time Systems, Geographic Information Systems (GIS)

---

## 1. Project Overview

The **Real-Time Disaster Alert and Emergency Response System (ResQ-Alert)** is an advanced web-based platform designed to provide timely disaster warnings, emergency information, and tactical coordination during natural and man-made disasters.

The system aggregates data from seismic monitoring agencies (USGS Real-Time Earthquake Monitor), meteorological radar services (Open-Meteo), and emergency management organizations to detect potential disasters such as **cyclones, flash floods, earthquakes, wildfires, and landslides**.

### Primary Objectives
- **Zero-Latency Alert Dissemination:** Broadcast critical hazard warnings in real time via WebSockets, simulated SMS gateways, and email alerts.
- **Dynamic Evacuation Routing:** Calculate optimal escape routes to verified safe shelters while automatically detouring around high-risk hazard zones.
- **Citizen SOS Crowdsourcing:** Enable trapped citizens to report emergencies with GPS coordinates, situation descriptions, victim counts, and photo attachments.
- **Authority Command Center:** Equip disaster management authorities with live incident triage boards, rescue team dispatching tools, and audio siren broadcasters.

---

## 2. System Architecture

```
+-------------------------------------------------------------------------------+
|                           CLIENT LAYER (React.js)                             |
|  - Tactical Live Map (Leaflet)          - Evacuation Route Guidance Engine    |
|  - Citizen SOS Photo/GPS Reporter       - Authority Command & Triage Board   |
|  - Real-Time Audio Siren Beep           - 72-Hour Offline Survival Checklist  |
+-------------------------------------------------------------------------------+
                                      │  ▲
                     HTTP / REST APIs │  │  WebSocket (Socket.io)
                                      ▼  │
+-------------------------------------------------------------------------------+
|                           BACKEND LAYER (Node.js & Express)                   |
|  - Authentication & JWT Middleware      - Multi-Channel Notification Engine   |
|  - Multer Photo Storage Handler         - Real-Time WebSocket Event Broker    |
|  - USGS Seismic & Open-Meteo Syncer    - Haversine Distance Router           |
+-------------------------------------------------------------------------------+
                                      │  ▲
                                      ▼  │
+-------------------------------------------------------------------------------+
|                           DATA PERSISTENCE LAYER                              |
|  - Dual-Mode Architecture: MongoDB (Mongoose ODM) + Persistent JSON Adapter   |
|  - Collections: Users, Alerts, IncidentReports, Shelters, NotificationLogs    |
+-------------------------------------------------------------------------------+
```

---

## 3. Key Features

| Feature | Description | Technical Implementation |
| :--- | :--- | :--- |
| **Interactive Disaster Map** | Interactive satellite/street mapping with color-coded hazard perimeters (Critical Red, High Orange, Moderate Yellow), shelter markers, and incident pins. | Leaflet.js, React-Leaflet, OpenStreetMap Tile Layers |
| **Safe Evacuation Routing** | Computes the shortest and safest escape path from user's GPS coordinates to the nearest shelter, avoiding active danger radius perimeters. | Custom Polygon/Radius Hazard Evasion Algorithm, Haversine Distance, Leaflet Polylines |
| **Real-Time Warning Siren** | Emergency broadcast popup with synthesized audible alarm beeping on all active devices. | Web Audio API Synthesizer, Socket.io Broadcast |
| **Citizen SOS Reporting** | Citizens can submit photo evidence, auto-detect GPS coordinates, specify trapped victims count, and report hazards. | HTML5 Geolocation API, Multer Multipart Uploads, Base64 Fallback |
| **Authority Command Center** | Triage incoming reports, verify situations, dispatch NDRF/Fire squads, mark incidents resolved, and push alerts. | Express REST APIs, Real-time status sync via Socket.io |
| **Hospital & Shelter Locator** | Directory of emergency shelters and trauma hospitals with live bed occupancy meters and direct calling. | Real-time capacity trackers, dynamic filtering |
| **Live Seismic & Weather Feeds** | Real-time global and regional earthquake magnitudes and meteorological storm squalls. | USGS GeoJSON Real-Time API, Open-Meteo Forecast API |
| **Role-Based Access Control** | Secure authentication for Citizens vs Disaster Officers with 1-click Quick Demo Logins for evaluators. | JWT (JSON Web Tokens), BCrypt Password Hashing |

---

## 4. Technology Stack

### Frontend
- **Framework:** React.js (v18) with Vite
- **Styling:** Tailwind CSS, PostCSS, Custom Tactical HUD theme
- **Icons & Visuals:** Lucide React, Canvas Confetti
- **Mapping:** Leaflet (v1.9), React-Leaflet (v4.2), OpenStreetMap
- **Real-Time Client:** Socket.io-client
- **Audio:** Web Audio API (Hardware-independent synthesized siren)

### Backend
- **Runtime:** Node.js (v20 LTS)
- **Web Framework:** Express.js (v4)
- **Real-Time WebSockets:** Socket.io (v4)
- **File Uploads:** Multer
- **HTTP Client:** Axios (for external USGS & Weather feeds)
- **Security:** JSON Web Tokens (JWT), BCrypt.js password hashing, CORS

### Database (Dual-Mode Design)
- **Mode 1 (Production):** MongoDB with Mongoose ODM schemas and indexes.
- **Mode 2 (Zero-Hassle Evaluator Mode):** Embedded Persistent JSON Storage with identical Mongoose-compatible schema methods (`find`, `create`, `findByIdAndUpdate`, `countDocuments`). Automatically activates when MongoDB server is not locally running, guaranteeing 100% test reliability on any examiner machine!

---

## 5. Pre-Configured Demo Accounts

For evaluation and viva demonstrations, 1-Click Quick Demo Login buttons are available in the top bar and login modal:

| Role | Email | Password | Permissions |
| :--- | :--- | :--- | :--- |
| **Disaster Authority Officer** | `officer@disaster-response.gov` | `Officer123!` | Incident triage, team dispatch, siren broadcast |
| **Citizen Resident** | `citizen@example.com` | `Citizen123!` | Map viewing, route guidance, SOS reporting |

---

## 6. REST API Endpoints

### Authentication (`/api/auth`)
- `POST /api/auth/register` - Create new citizen or authority account
- `POST /api/auth/login` - Sign in and receive JWT token
- `POST /api/auth/demo/:role` - 1-Click demo authentication (`citizen` or `authority`)
- `GET /api/auth/me` - Retrieve current authenticated profile

### Disaster Alerts (`/api/alerts`)
- `GET /api/alerts` - List active disaster warnings (filters: `severity`, `type`)
- `GET /api/alerts/live-feeds` - Fetch live USGS earthquakes and Open-Meteo weather
- `POST /api/alerts` - Broadcast new disaster warning *(Authority clearance required)*
- `PUT /api/alerts/:id` - Update alert status or instructions
- `DELETE /api/alerts/:id` - Revoke or delete alert

### Incident Reports (`/api/reports`)
- `GET /api/reports` - Retrieve all citizen SOS reports
- `POST /api/reports` - Submit new emergency incident with GPS and photo
- `PATCH /api/reports/:id/status` - Update triage (`verified`, `dispatched`, `resolved`)
- `DELETE /api/reports/:id` - Delete report

### Shelters & Hospitals (`/api/shelters`)
- `GET /api/shelters` - Get all shelters sorted by proximity if user coordinates provided
- `GET /api/shelters/hotlines` - Emergency toll-free telephone numbers (112, 1078, 108, 101)
- `PATCH /api/shelters/:id/occupancy` - Update live occupied beds count

### Analytics & Stats (`/api/stats`)
- `GET /api/stats` - Return active alerts, pending reports, bed counts, and notification logs

---

## 7. How to Run the Project

### Method 1: 1-Click Execution (Windows)
Double-click `start.bat` in the project root directory:
```cmd
start.bat
```
This automatically verifies Node.js, boots the unified server on port `5000`, and opens your default browser to `http://localhost:5000`.

### Method 2: Manual Execution
#### Terminal 1: Backend Server
```bash
cd backend
npm install
node server.js
```
The server will boot on `http://localhost:5000`.

#### (Optional) Terminal 2: Frontend Vite Development Server
```bash
cd frontend
npm install
npm run dev
```
Access Vite hot-reload development at `http://localhost:3000`.

---

## 8. Common Viva / Examiner Questions & Answers

**Q1: How does the system achieve real-time synchronization without manual page refreshing?**  
*Answer:* The platform implements a bi-directional WebSocket connection powered by `Socket.io`. When an authority officer broadcasts a siren or a citizen transmits a photo SOS, the backend publishes event payloads (`emergency_broadcast`, `new_incident_report`) to all connected sockets in milliseconds.

**Q2: How does the Evacuation Route Guidance avoid active hazard zones?**  
*Answer:* The system runs a geometric collision detection check between the line segment connecting the user's coordinates to the target shelter and the circular hazard perimeters of active critical alerts. When an intersection is detected, it computes tangent detour waypoints around the perimeter radius, returning a safe detour corridor.

**Q3: How are passwords and authentication secured?**  
*Answer:* Passwords are salted and hashed using `bcryptjs` with 10 salt rounds before storage. Upon successful login, the server issues a signed JSON Web Token (JWT) containing the user ID and role, which the client transmits in HTTP Bearer headers for protected endpoints.

**Q4: What happens if an external API (like USGS or Open-Meteo) experiences downtime?**  
*Answer:* The external feed service is designed with defensive fault-tolerance. Requests feature strict timeout constraints, and if the network is interrupted, the system automatically falls back to pre-cached regional seismic and meteorological telemetry models without interrupting user flows.
