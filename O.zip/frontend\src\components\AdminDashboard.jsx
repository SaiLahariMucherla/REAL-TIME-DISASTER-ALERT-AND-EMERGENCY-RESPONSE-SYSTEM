import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Radio,
  Users,
  CheckCircle,
  Truck,
  Send,
  AlertOctagon,
  Clock,
  Eye,
  Check,
  XCircle,
  FileText,
  Mail,
  MessageSquare,
  BellRing,
  RefreshCw,
  PlusCircle,
  Sliders
} from 'lucide-react';
import { alertService, reportService, statsService, shelterService } from '../services/api';
import confetti from 'canvas-confetti';

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [reports, setReports] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState(null);

  // Broadcast Alert Form
  const [broadcastForm, setBroadcastForm] = useState({
    title: '',
    type: 'cyclone',
    severity: 'critical',
    description: '',
    area: 'Coastal Andhra / Kakinada Shoreline',
    city: 'Kakinada',
    lat: 16.9891,
    lng: 82.2475,
    radiusKm: 20,
    instructions: 'Evacuate to elevated shelters immediately. Secure loose outdoor property. Dial 112 for rescue.'
  });
  const [broadcasting, setBroadcasting] = useState(false);
  const [broadcastSuccess, setBroadcastSuccess] = useState(false);

  // Dispatch Action State
  const [dispatchUnitName, setDispatchUnitName] = useState('NDRF Quick Response Team 03');

  const loadAllData = async () => {
    try {
      setLoading(true);
      const [statsRes, reportsRes, alertsRes] = await Promise.all([
        statsService.getDashboard(),
        reportService.getAll(),
        alertService.getAll()
      ]);

      if (statsRes.data.success) {
        setStats(statsRes.data.stats);
        setNotifications(statsRes.data.recentNotifications || []);
      }
      if (reportsRes.data.success) setReports(reportsRes.data.reports);
      if (alertsRes.data.success) setAlerts(alertsRes.data.alerts);
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  // Handle Triage Update (Verify / Dispatch / Resolve)
  const handleUpdateStatus = async (reportId, newStatus, unit = '') => {
    try {
      const res = await reportService.updateStatus(reportId, {
        status: newStatus,
        dispatchedUnit: unit || dispatchUnitName,
        adminNotes: `Updated to ${newStatus} at ${new Date().toLocaleTimeString()}`
      });

      if (res.data.success) {
        setReports(prev => prev.map(r => (r._id === reportId ? res.data.report : r)));
        if (newStatus === 'resolved') {
          confetti({ particleCount: 80, spread: 70 });
        }
        loadAllData();
      }
    } catch (err) {
      alert('Error updating status: ' + (err.response?.data?.message || err.message));
    }
  };

  // Handle Broadcast Disaster Warning
  const handleBroadcastAlert = async (e) => {
    e.preventDefault();
    setBroadcasting(true);
    setBroadcastSuccess(false);

    try {
      const res = await alertService.create({
        title: broadcastForm.title,
        type: broadcastForm.type,
        severity: broadcastForm.severity,
        description: broadcastForm.description,
        location: {
          area: broadcastForm.area,
          city: broadcastForm.city,
          lat: parseFloat(broadcastForm.lat),
          lng: parseFloat(broadcastForm.lng),
          radiusKm: parseFloat(broadcastForm.radiusKm)
        },
        instructions: broadcastForm.instructions.split('.').filter(Boolean).map(s => s.trim())
      });

      if (res.data.success) {
        setBroadcastSuccess(true);
        confetti({ particleCount: 100, spread: 80 });
        setBroadcastForm({
          title: '',
          type: 'cyclone',
          severity: 'critical',
          description: '',
          area: 'Coastal Andhra / Kakinada Shoreline',
          city: 'Kakinada',
          lat: 16.9891,
          lng: 82.2475,
          radiusKm: 20,
          instructions: 'Evacuate to elevated shelters immediately. Secure loose outdoor property. Dial 112 for rescue.'
        });
        loadAllData();
        setTimeout(() => setBroadcastSuccess(false), 5000);
      }
    } catch (err) {
      alert('Broadcast failed: ' + (err.response?.data?.message || err.message));
    } finally {
      setBroadcasting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-bold uppercase tracking-wider mb-1">
            <ShieldAlert className="w-4 h-4" />
            National Disaster Response Cell • Command & Dispatch
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Authority Emergency Command Center
          </h1>
          <p className="text-sm text-slate-400">
            Real-time incident triage, rescue unit dispatching, and multi-channel public siren broadcaster.
          </p>
        </div>

        <button
          onClick={loadAllData}
          disabled={loading}
          className="self-start sm:self-auto px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 border border-slate-700 transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh Live Grid
        </button>
      </div>

      {/* KPI Stats Cards */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          <div className="bg-slate-900 border border-red-500/30 p-4 rounded-2xl">
            <div className="text-[10px] font-mono text-red-400 uppercase font-bold">Active Hazards</div>
            <div className="text-2xl font-black text-white mt-1">{stats.activeAlertsCount}</div>
            <div className="text-[10px] text-red-400/80 mt-1 font-mono">{stats.criticalAlertsCount} Critical Red</div>
          </div>

          <div className="bg-slate-900 border border-amber-500/30 p-4 rounded-2xl">
            <div className="text-[10px] font-mono text-amber-400 uppercase font-bold">Pending SOS</div>
            <div className="text-2xl font-black text-amber-400 mt-1">{stats.pendingReportsCount}</div>
            <div className="text-[10px] text-slate-400 mt-1 font-mono">Triage Required</div>
          </div>

          <div className="bg-slate-900 border border-blue-500/30 p-4 rounded-2xl">
            <div className="text-[10px] font-mono text-blue-400 uppercase font-bold">Dispatched Teams</div>
            <div className="text-2xl font-black text-blue-400 mt-1">{stats.dispatchedReportsCount}</div>
            <div className="text-[10px] text-slate-400 mt-1 font-mono">In Transit / Rescuing</div>
          </div>

          <div className="bg-slate-900 border border-emerald-500/30 p-4 rounded-2xl">
            <div className="text-[10px] font-mono text-emerald-400 uppercase font-bold">Incidents Resolved</div>
            <div className="text-2xl font-black text-emerald-400 mt-1">{stats.resolvedReportsCount}</div>
            <div className="text-[10px] text-slate-400 mt-1 font-mono">Safe Closures</div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
            <div className="text-[10px] font-mono text-slate-400 uppercase font-bold">Available Beds</div>
            <div className="text-2xl font-black text-white mt-1">{stats.totalAvailableBeds}</div>
            <div className="text-[10px] text-emerald-400 mt-1 font-mono">Across {stats.totalSheltersCount} Camps</div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
            <div className="text-[10px] font-mono text-slate-400 uppercase font-bold">Data Store Mode</div>
            <div className="text-xs font-bold text-slate-200 mt-1 truncate">{stats.dbStatus?.mode}</div>
            <div className="text-[10px] text-emerald-400 mt-1 font-mono flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Fully Synchronized
            </div>
          </div>
        </div>
      )}

      {/* Main Grid: Left Triage Board, Right Broadcast Broadcaster */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: Citizen SOS Incident Triage (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-amber-400" />
                <h2 className="text-lg font-bold text-white">Live Citizen SOS Incident Queue</h2>
              </div>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-800 text-slate-300 border border-slate-700">
                {reports.length} Total Reports
              </span>
            </div>

            <div className="space-y-3 max-h-[620px] overflow-y-auto pr-1">
              {reports.map((report) => {
                const isPending = report.status === 'pending';
                const isDispatched = report.status === 'dispatched';
                const isResolved = report.status === 'resolved';

                return (
                  <div
                    key={report._id || report.id}
                    className={`p-4 rounded-2xl border transition-all ${
                      isPending
                        ? 'bg-amber-950/20 border-amber-600/40 shadow-lg shadow-amber-950/30'
                        : isDispatched
                        ? 'bg-blue-950/20 border-blue-600/40'
                        : 'bg-slate-950/60 border-slate-800 opacity-70'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded text-white ${
                          isPending ? 'bg-amber-600 animate-pulse' : isDispatched ? 'bg-blue-600' : 'bg-emerald-600'
                        }`}>
                          {report.status}
                        </span>
                        <span className="text-xs font-semibold text-slate-400 uppercase font-mono">
                          {report.disasterType}
                        </span>
                        {report.victimsCount > 0 && (
                          <span className="text-xs text-red-400 font-bold bg-red-500/10 px-2 py-0.5 rounded border border-red-500/20">
                            {report.victimsCount} Victims Trapped
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] font-mono text-slate-500">
                        {new Date(report.createdAt).toLocaleTimeString()}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-white mb-1">{report.title}</h3>
                    <p className="text-xs text-slate-300 leading-relaxed mb-2">{report.description}</p>

                    {/* Address & GPS */}
                    <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mb-3 font-mono">
                      <span>📍 {report.location.address}</span>
                      <span className="text-slate-600">|</span>
                      <span>[{report.location.lat.toFixed(4)}, {report.location.lng.toFixed(4)}]</span>
                    </div>

                    {/* Image Attachment Thumbnail if present */}
                    {report.imageUrl && (
                      <div className="mb-3">
                        <img
                          src={report.imageUrl}
                          alt="Evidence"
                          className="h-28 w-48 object-cover rounded-xl border border-slate-700 shadow-md"
                        />
                      </div>
                    )}

                    {/* Action Controls for Authority */}
                    <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div className="text-[11px] text-slate-400">
                        Reporter: <span className="text-slate-200 font-semibold">{report.reporterName}</span> ({report.reporterPhone || 'No phone'})
                      </div>

                      <div className="flex items-center gap-1.5">
                        {isPending && (
                          <button
                            onClick={() => handleUpdateStatus(report._id || report.id, 'verified')}
                            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold border border-slate-700 flex items-center gap-1"
                          >
                            <Check className="w-3.5 h-3.5 text-blue-400" /> Verify
                          </button>
                        )}

                        {!isDispatched && !isResolved && (
                          <button
                            onClick={() => handleUpdateStatus(report._id || report.id, 'dispatched', 'NDRF Coastal Unit 02')}
                            className="px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold flex items-center gap-1 shadow-md shadow-blue-600/30"
                          >
                            <Truck className="w-3.5 h-3.5" /> Dispatch Team
                          </button>
                        )}

                        {!isResolved && (
                          <button
                            onClick={() => handleUpdateStatus(report._id || report.id, 'resolved')}
                            className="px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1 shadow-md shadow-emerald-600/30"
                          >
                            <CheckCircle className="w-3.5 h-3.5" /> Mark Resolved
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Side: Broadcast Emergency Siren & Notification Audit (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Emergency Alert Broadcast Form */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
            <div className="flex items-center gap-2 mb-3">
              <Radio className="w-5 h-5 text-red-500 animate-pulse" />
              <h2 className="text-lg font-bold text-white">Broadcast Public Warning Siren</h2>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              Instantly pushes an emergency popup, audible siren beep, and SMS/Email log to all citizens in the hazard perimeter.
            </p>

            {broadcastSuccess && (
              <div className="p-3 mb-4 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Emergency siren broadcasted across all connected devices!</span>
              </div>
            )}

            <form onSubmit={handleBroadcastAlert} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-300 uppercase mb-1">
                  Alert Headline *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. FLASH FLOOD: Immediate Riverbank Evacuation"
                  value={broadcastForm.title}
                  onChange={(e) => setBroadcastForm({ ...broadcastForm, title: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-red-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-300 uppercase mb-1">Disaster Type</label>
                  <select
                    value={broadcastForm.type}
                    onChange={(e) => setBroadcastForm({ ...broadcastForm, type: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-2 text-white focus:outline-none focus:border-red-500"
                  >
                    <option value="cyclone">Cyclone</option>
                    <option value="flood">Flood</option>
                    <option value="earthquake">Earthquake</option>
                    <option value="wildfire">Wildfire</option>
                    <option value="landslide">Landslide</option>
                    <option value="storm">Storm</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-300 uppercase mb-1">Severity</label>
                  <select
                    value={broadcastForm.severity}
                    onChange={(e) => setBroadcastForm({ ...broadcastForm, severity: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-2 text-white focus:outline-none focus:border-red-500"
                  >
                    <option value="critical">🔴 Critical Red</option>
                    <option value="high">🟠 High Orange</option>
                    <option value="moderate">🟡 Moderate Yellow</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 uppercase mb-1">Target Area / Region</label>
                <input
                  type="text"
                  required
                  value={broadcastForm.area}
                  onChange={(e) => setBroadcastForm({ ...broadcastForm, area: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-red-500"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-bold text-slate-400 uppercase mb-1">LAT</label>
                  <input
                    type="number"
                    step="any"
                    value={broadcastForm.lat}
                    onChange={(e) => setBroadcastForm({ ...broadcastForm, lat: parseFloat(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2 py-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-400 uppercase mb-1">LNG</label>
                  <input
                    type="number"
                    step="any"
                    value={broadcastForm.lng}
                    onChange={(e) => setBroadcastForm({ ...broadcastForm, lng: parseFloat(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2 py-1.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-400 uppercase mb-1">Radius (km)</label>
                  <input
                    type="number"
                    value={broadcastForm.radiusKm}
                    onChange={(e) => setBroadcastForm({ ...broadcastForm, radiusKm: parseFloat(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2 py-1.5 text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-300 uppercase mb-1">Detailed Situation & Warnings</label>
                <textarea
                  rows={2}
                  required
                  placeholder="Official advisory text..."
                  value={broadcastForm.description}
                  onChange={(e) => setBroadcastForm({ ...broadcastForm, description: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-red-500"
                />
              </div>

              <button
                type="submit"
                disabled={broadcasting}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-red-600/30 active:scale-98 transition-all disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span>{broadcasting ? 'TRANSMITTING SIREN...' : 'PUSH EMERGENCY WARNING SIREN'}</span>
              </button>
            </form>
          </div>

          {/* Multi-Channel Notification Audit Feed */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <BellRing className="w-4 h-4 text-blue-400" />
                <h3 className="font-bold text-white text-sm">Multi-Channel Broadcast Audit</h3>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">Simulated Gateways</span>
            </div>

            <div className="space-y-2 max-h-48 overflow-y-auto pr-1 text-xs font-mono">
              {notifications.map((n, i) => (
                <div key={n._id || i} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                  <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                    <span className="flex items-center gap-1 font-bold uppercase text-slate-300">
                      {n.channel === 'sms_gateway' && <MessageSquare className="w-3 h-3 text-emerald-400" />}
                      {n.channel === 'email_broadcast' && <Mail className="w-3 h-3 text-blue-400" />}
                      {n.channel === 'web_push' && <Radio className="w-3 h-3 text-red-400" />}
                      {n.channel}
                    </span>
                    <span>{new Date(n.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <div className="text-slate-200 font-sans text-[11px] font-semibold">{n.title}</div>
                  <div className="text-slate-400 font-sans text-[10px] line-clamp-1">{n.message}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
