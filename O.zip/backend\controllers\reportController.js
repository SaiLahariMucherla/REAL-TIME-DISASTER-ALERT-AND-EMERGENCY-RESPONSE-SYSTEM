const { IncidentReport } = require('../models/dataRepository');
const notificationService = require('../services/notificationService');

// Get all reports
exports.getAllReports = async (req, res) => {
  try {
    const { status, disasterType } = req.query;
    let reports = await IncidentReport.find();

    if (status && status !== 'all') {
      reports = reports.filter(r => r.status === status.toLowerCase());
    }
    if (disasterType && disasterType !== 'all') {
      reports = reports.filter(r => r.disasterType === disasterType.toLowerCase());
    }

    return res.json({
      success: true,
      count: reports.length,
      reports
    });
  } catch (error) {
    console.error('[reportController.getAllReports]', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve reports' });
  }
};

// Create new report (Citizen SOS reporting)
exports.createReport = async (req, res) => {
  try {
    const {
      title,
      disasterType,
      severity,
      description,
      location,
      imageUrl,
      reporterName,
      reporterPhone,
      victimsCount
    } = req.body;

    if (!title || !disasterType || !description || !location || !location.address || !location.lat || !location.lng) {
      return res.status(400).json({
        success: false,
        message: 'Please provide title, disaster type, description, and valid GPS location.'
      });
    }

    // Check if image file was uploaded via multer
    let finalImageUrl = imageUrl || '';
    if (req.file) {
      finalImageUrl = `/uploads/${req.file.filename}`;
    }

    const report = await IncidentReport.create({
      title,
      disasterType: disasterType.toLowerCase(),
      severity: severity || 'high',
      description,
      location: {
        address: location.address,
        lat: parseFloat(location.lat),
        lng: parseFloat(location.lng)
      },
      imageUrl: finalImageUrl,
      reporterName: reporterName || (req.user ? req.user.name : 'Anonymous Citizen'),
      reporterPhone: reporterPhone || (req.user ? req.user.phone : ''),
      victimsCount: victimsCount ? parseInt(victimsCount, 10) : 0,
      status: 'pending',
      dispatchedUnit: '',
      adminNotes: '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    // Notify Authority Command Center in real-time
    await notificationService.notifyAuthorityNewReport(report);

    return res.status(201).json({
      success: true,
      message: 'Emergency incident reported. Response authorities have been notified.',
      report
    });
  } catch (error) {
    console.error('[reportController.createReport]', error);
    return res.status(500).json({ success: false, message: 'Failed to submit incident report' });
  }
};

// Update report triage status (Authority action)
exports.updateReportStatus = async (req, res) => {
  try {
    const { status, dispatchedUnit, adminNotes } = req.body;
    const report = await IncidentReport.findById(req.params.id);

    if (!report) {
      return res.status(404).json({ success: false, message: 'Report not found' });
    }

    const updateData = {};
    if (status) updateData.status = status;
    if (dispatchedUnit !== undefined) updateData.dispatchedUnit = dispatchedUnit;
    if (adminNotes !== undefined) updateData.adminNotes = adminNotes;
    updateData.updatedAt = new Date().toISOString();

    const updated = await IncidentReport.findByIdAndUpdate(req.params.id, updateData);

    // Notify connected clients of the status update
    await notificationService.notifyReportStatusUpdate(updated);

    return res.json({
      success: true,
      message: `Incident status updated to ${status || 'updated'}`,
      report: updated
    });
  } catch (error) {
    console.error('[reportController.updateReportStatus]', error);
    return res.status(500).json({ success: false, message: 'Failed to update report status' });
  }
};

// Delete report
exports.deleteReport = async (req, res) => {
  try {
    const deleted = await IncidentReport.findByIdAndDelete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: 'Report not found' });
    }
    return res.json({ success: true, message: 'Report deleted' });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Failed to delete report' });
  }
};
