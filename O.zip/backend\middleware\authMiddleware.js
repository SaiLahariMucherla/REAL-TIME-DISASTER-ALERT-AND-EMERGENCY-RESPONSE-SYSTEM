const jwt = require('jsonwebtoken');
const config = require('../config/config');

// Verify Bearer Token
exports.protect = (req, res, next) => {
  let token;
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return res.status(401).json({ success: false, message: 'Authorization token missing or invalid.' });
  }

  try {
    const decoded = jwt.verify(token, config.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ success: false, message: 'Token is expired or invalid.' });
  }
};

// Require Authority role
exports.requireAuthority = (req, res, next) => {
  if (!req.user || req.user.role !== 'authority') {
    return res.status(403).json({
      success: false,
      message: 'Access restricted: Disaster Management Authority clearance required.'
    });
  }
  next();
};
