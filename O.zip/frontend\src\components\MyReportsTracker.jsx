import React, { useState, useEffect } from 'react';
import {
  FileText,
  Clock,
  CheckCircle,
  Truck,
  ShieldCheck,
  Search,
  AlertTriangle,
  RefreshCw,
  Phone,
  MapPin,
  Users,
  ChevronRight,
  ExternalLink
} from 'lucide-react';
import { reportService } from '../services/api';
import { useSocket } from '../context/SocketContext';
import { useAuth } from '../context/AuthContext';

const MyReportsTracker = ({ onOpenReportModal }) => {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchId, setSearchId] = useState('');
  const [searchedReport, setSearchedReport] = useState(null);
  const [searchError, setSearchError] = useState('');
  const { user } = useAuth();
  const { socket } = useSocket();

  // Load user's filed reports (from localStorage + matching user)
  const fetchMyReports = async () => {
    try {
      setLoading(true);
      const res = await reportService.getAll();
      if (res.data.success) {
        const all = res.data.reports;
        const mySavedIds = JSON.parse(localStorage.getItem('resq_my_reports') || '[]');

        // Filter reports that match saved local IDs, or match current user name/phone
        const myFiltered = all.filter(r => {
          if (mySavedIds.includes(r._id || r.id)) return true;
          if (user && r.reporterName === user.name) return true;
          if (user && user.phone && r.reporterPhone === user.phone) return true;
          return false;
        });

        // If user hasn't filed any yet, show the demo seeded reports so the user can immediately test and evaluate this feature!
        if (myFiltered.length === 0) {
          setReports(all);
        } else {
          setReports(myFiltered);
        }
      }
    } catch (err) {
      console.warn('Error fetching reports:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMyReports();

    // Listen for real-time status updates from authorities
    if (socket) {
      const handleStatusUpdate = (updatedReport) => {
        setReports(prev =>
          prev.map(r => ((r._id === updatedReport._id || r.id === updatedReport._id) ? updatedReport : r))
        );
        if (searchedReport && (searchedReport._id === updatedReport._id || searchedReport.id === updatedReport._id)) {
          setSearchedReport(updatedReport);
        }
      };

      socket.on('incident_status_updated', handleStatusUpdate);
      return () => {
        socket.off('incident_status_updated', handleStatusUpdate);
      };
    }
  }, [socket, user]);

  const handleSearchById = async (e) => {
    e.preventDefault();
    if (!searchId.trim()) return;
    setSearchError('');
    setSearchedReport(null);

    try {
      const res = await reportService.getAll();
      if (res.data.success) {
        const q = searchId.trim().toLowerCase();
        const found = res.data.reports.find(r =>
          (r._id && r._id.toLowerCase().includes(q)) ||
          (r.reporterPhone && r.reporterPhone.includes(q))
        );

        if (found) {
          setSearchedReport(found);
        } else {
          setSearchError('No emergency incident found with that ID or Phone Number.');
        }
      }
    } catch (err) {
      setSearchError('Lookup error. Please try again.');
    }
  };

  const getStatusStep = (status) => {
    switch (status) {
      case 'pending': return 1;
      case 'verified': return 2;
      case 'dispatched': return 3;
      case 'resolved': return 4;
      default: return 1;
    }
  };

  const renderTimeline = (report) => {
    const step = getStatusStep(report.status);

    const steps = [
      {
        num: 1,
        title: 'SOS Transmitted',
        desc: 'Logged in Disaster Network',
        active: step >= 1,
        color: 'text-blue-400'
      },
      {
        num: 2,
        title: 'Officer Approval',
        desc: step >= 2 ? 'Verified by Command Officer' : 'Awaiting Officer Review',
        active: step >= 2,
        color: 'text-amber-400'
      },
      {
        num: 3,
        title: 'Team Dispatched',
        desc: report.dispatchedUnit || 'Rescue Unit En Route',
        active: step >= 3,
        color: 'text-orange-400'
      },
      {
        num: 4,
        title: 'Safe Resolution',
        desc: 'Operation Complete & Secured',
        active: step >= 4,
        color: 'text-emerald-400'
      }
    ];

    return (
      <div className="py-4">
        <div className="grid grid-cols-4 gap-2 relative">
          {steps.map((s, idx) => (
            <div key={s.num} className="flex flex-col items-center text-center">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs mb-2 transition-all ${
                  s.active
                    ? 'bg-emerald-600 text-white ring-4 ring-emerald-500/20'
                    : 'bg-slate-800 text-slate-500 border border-slate-700'
                }`}
              >
                {s.active ? '✓' : s.num}
              </div>
              <div className="text-xs font-bold text-slate-200">{s.title}</div>
              <div className="text-[10px] text-slate-400 line-clamp-1">{s.desc}</div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-bold uppercase tracking-wider mb-1">
            <FileText className="w-4 h-4" />
            Victim Live Incident Tracker
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Track SOS Emergency Response & Officer Approvals
          </h1>
          <p className="text-sm text-slate-400">
            Real-time status updates showing whether disaster officers have approved and dispatched rescue squads to your emergency.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchMyReports}
            disabled={loading}
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
            title="Refresh Incident Status"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={onOpenReportModal}
            className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-red-600/20"
          >
            <AlertTriangle className="w-4 h-4" />
            Report New SOS
          </button>
        </div>
      </div>

      {/* Reference ID / Phone Search Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
        <form onSubmit={handleSearchById} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by Reference ID (e.g. report_01, id_3fzaf2f...) or Reporter Phone..."
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
          </div>
          <button
            type="submit"
            className="px-5 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shrink-0"
          >
            Track Status
          </button>
        </form>

        {searchError && (
          <p className="text-xs text-red-400 mt-2">{searchError}</p>
        )}

        {searchedReport && (
          <div className="mt-4 p-4 rounded-2xl bg-slate-950 border border-amber-500/40 animate-fade-in">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono font-bold text-amber-400 uppercase">
                Search Result: {searchedReport._id}
              </span>
              <span className={`text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full text-white ${
                searchedReport.status === 'pending'
                  ? 'bg-amber-600'
                  : searchedReport.status === 'dispatched'
                  ? 'bg-blue-600'
                  : 'bg-emerald-600'
              }`}>
                {searchedReport.status}
              </span>
            </div>
            <h3 className="font-bold text-white text-base">{searchedReport.title}</h3>
            <p className="text-xs text-slate-300 mt-1">{searchedReport.description}</p>
            {renderTimeline(searchedReport)}
          </div>
        )}
      </div>

      {/* Reports List */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold text-slate-400 uppercase tracking-wider font-mono">
          Your Active & Monitored Emergency Incidents ({reports.length})
        </h2>

        {reports.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center space-y-3">
            <FileText className="w-12 h-12 text-slate-600 mx-auto" />
            <h3 className="text-base font-bold text-white">No Emergency Reports Filed Yet</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              If you or someone nearby is experiencing a disaster emergency, click below to transmit an SOS report with photo evidence.
            </p>
            <button
              onClick={onOpenReportModal}
              className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs inline-flex items-center gap-2"
            >
              Report Emergency SOS
            </button>
          </div>
        ) : (
          reports.map((report) => {
            const isPending = report.status === 'pending';
            const isVerified = report.status === 'verified';
            const isDispatched = report.status === 'dispatched';
            const isResolved = report.status === 'resolved';

            return (
              <div
                key={report._id || report.id}
                className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4 hover:border-slate-700 transition-all"
              >
                {/* Header Row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                  <div className="flex items-center gap-3">
                    <span className={`text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-full text-white ${
                      isPending
                        ? 'bg-amber-600 animate-pulse'
                        : isVerified
                        ? 'bg-blue-600'
                        : isDispatched
                        ? 'bg-orange-600'
                        : 'bg-emerald-600'
                    }`}>
                      {isPending && '⏳ PENDING OFFICER REVIEW'}
                      {isVerified && '✓ APPROVED BY DISASTER OFFICER'}
                      {isDispatched && '🚒 RESCUE TEAM DISPATCHED'}
                      {isResolved && '🎉 SAFELY RESOLVED'}
                    </span>

                    <span className="text-xs font-mono text-slate-400">
                      ID: <strong className="text-slate-200">{report._id}</strong>
                    </span>
                  </div>

                  <span className="text-xs text-slate-400 font-mono">
                    Reported: {new Date(report.createdAt).toLocaleString()}
                  </span>
                </div>

                {/* Details */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                  <div className="md:col-span-8 space-y-2">
                    <h3 className="text-lg font-bold text-white">{report.title}</h3>
                    <p className="text-xs text-slate-300 leading-relaxed">{report.description}</p>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 pt-1 font-mono">
                      <span className="flex items-center gap-1 text-slate-300">
                        <MapPin className="w-3.5 h-3.5 text-red-400" />
                        {report.location.address}
                      </span>
                      <span>•</span>
                      <span>GPS: [{report.location.lat.toFixed(4)}, {report.location.lng.toFixed(4)}]</span>
                      {report.victimsCount > 0 && (
                        <>
                          <span>•</span>
                          <span className="text-red-400 font-bold">Victims: {report.victimsCount} trapped</span>
                        </>
                      )}
                    </div>

                    {/* Officer Status Box */}
                    <div className={`p-3.5 rounded-2xl border text-xs space-y-1 mt-3 ${
                      isPending
                        ? 'bg-amber-950/20 border-amber-600/30 text-amber-300'
                        : isDispatched
                        ? 'bg-blue-950/20 border-blue-600/30 text-blue-300'
                        : 'bg-emerald-950/20 border-emerald-600/30 text-emerald-300'
                    }`}>
                      <div className="font-bold flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 shrink-0" />
                        <span>Authority Action Status:</span>
                      </div>
                      <div className="text-[11px] leading-relaxed">
                        {isPending && (
                          <span>Your emergency report has been routed to the Response Center. Disaster officers are currently assessing site priority.</span>
                        )}
                        {isVerified && (
                          <span>✅ <strong>OFFICER VERIFIED:</strong> Disaster response team has formally verified this incident. Rescue personnel are being organized.</span>
                        )}
                        {isDispatched && (
                          <span>🚒 <strong>UNIT IN TRANSIT:</strong> Dispatched Team: <strong className="text-white underline">{report.dispatchedUnit || 'NDRF Quick Action Team'}</strong>. Stay in elevated/secure position.</span>
                        )}
                        {isResolved && (
                          <span>🎉 <strong>OPERATION COMPLETE:</strong> Evacuation and assistance have been conducted successfully. Area is secured.</span>
                        )}
                      </div>
                      {report.adminNotes && (
                        <div className="text-[10px] text-slate-400 italic pt-1 border-t border-slate-800">
                          Officer Field Note: "{report.adminNotes}"
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Thumbnail / Image Evidence */}
                  <div className="md:col-span-4 flex flex-col items-center justify-center">
                    {report.imageUrl ? (
                      <div className="w-full h-36 rounded-2xl overflow-hidden border border-slate-800 relative">
                        <img
                          src={report.imageUrl}
                          alt="Incident proof"
                          className="w-full h-full object-cover"
                        />
                        <span className="absolute bottom-2 right-2 text-[10px] bg-black/70 px-2 py-0.5 rounded text-white font-mono">
                          Photo Attached
                        </span>
                      </div>
                    ) : (
                      <div className="w-full h-36 rounded-2xl border border-dashed border-slate-800 flex flex-col items-center justify-center text-slate-600 text-xs p-4 text-center">
                        <FileText className="w-6 h-6 mb-1 opacity-50" />
                        <span>No photo attached with this transmission</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Progress Visualizer */}
                <div className="pt-2 border-t border-slate-800/80">
                  {renderTimeline(report)}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default MyReportsTracker;
