import React, { createContext, useContext, useState, useEffect } from 'react';

const LocationContext = createContext(null);

export const PRESET_LOCATIONS = [
  { name: 'Hyderabad, Telangana', lat: 17.3850, lng: 78.4867, country: 'India' },
  { name: 'Visakhapatnam, Andhra Pradesh', lat: 17.6868, lng: 83.2185, country: 'India' },
  { name: 'Vijayawada, Andhra Pradesh', lat: 16.5062, lng: 80.6480, country: 'India' },
  { name: 'Chennai, Tamil Nadu', lat: 13.0827, lng: 80.2707, country: 'India' },
  { name: 'Mumbai, Maharashtra', lat: 19.0760, lng: 72.8777, country: 'India' },
  { name: 'Bengaluru, Karnataka', lat: 12.9716, lng: 77.5946, country: 'India' },
  { name: 'Kolkata, West Bengal', lat: 22.5726, lng: 88.3639, country: 'India' },
  { name: 'Delhi NCR', lat: 28.6139, lng: 77.2090, country: 'India' },
  { name: 'Kochi, Kerala', lat: 9.9312, lng: 76.2673, country: 'India' },
  { name: 'Bhubaneswar, Odisha', lat: 20.2961, lng: 85.8245, country: 'India' },
  { name: 'Tokyo, Japan', lat: 35.6762, lng: 139.6503, country: 'Japan' },
  { name: 'San Francisco, CA', lat: 37.7749, lng: -122.4194, country: 'USA' },
  { name: 'London, UK', lat: 51.5074, lng: -0.1278, country: 'UK' }
];

export const LocationProvider = ({ children }) => {
  // Load saved location from localStorage or default
  const [currentLocation, setCurrentLocation] = useState(() => {
    try {
      const saved = localStorage.getItem('resq_user_location');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      name: 'Hyderabad, Telangana',
      address: 'Central District, Hyderabad',
      lat: 17.3850,
      lng: 78.4867,
      isGPS: false
    };
  });

  const [isLocating, setIsLocating] = useState(false);
  const [locationModalOpen, setLocationModalOpen] = useState(false);

  // Save changes
  useEffect(() => {
    try {
      localStorage.setItem('resq_user_location', JSON.stringify(currentLocation));
    } catch (e) {}
  }, [currentLocation]);

  // Set location manually by coordinates and name
  const setManualLocation = (name, lat, lng, address = '') => {
    setCurrentLocation({
      name: name || `Lat: ${parseFloat(lat).toFixed(4)}, Lng: ${parseFloat(lng).toFixed(4)}`,
      address: address || name,
      lat: parseFloat(lat),
      lng: parseFloat(lng),
      isGPS: false
    });
  };

  // Geocode address or city name via OpenStreetMap Nominatim
  const searchAndSetLocation = async (query) => {
    if (!query || !query.trim()) return false;
    try {
      const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`;
      const response = await fetch(url, {
        headers: { 'Accept-Language': 'en' }
      });
      const data = await response.json();
      if (data && data.length > 0) {
        const place = data[0];
        setManualLocation(
          place.display_name.split(',').slice(0, 3).join(', '),
          parseFloat(place.lat),
          parseFloat(place.lon),
          place.display_name
        );
        return true;
      }
    } catch (e) {
      console.warn('Online geocoding lookup failed, checking local preset list:', e);
    }

    // Fallback: check local preset list
    const found = PRESET_LOCATIONS.find(p => p.name.toLowerCase().includes(query.toLowerCase()));
    if (found) {
      setManualLocation(found.name, found.lat, found.lng);
      return true;
    }
    return false;
  };

  // Browser Geolocation Detection
  const detectGPSLocation = () => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        alert('Geolocation is not supported by your browser.');
        return reject(new Error('Not supported'));
      }
      setIsLocating(true);
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;

          let name = `My Current Location (${lat.toFixed(3)}, ${lng.toFixed(3)})`;
          try {
            // Reverse geocode to get city name
            const revUrl = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`;
            const res = await fetch(revUrl);
            const data = await res.json();
            if (data?.address) {
              const city = data.address.city || data.address.town || data.address.village || data.address.county || 'Detected Area';
              const state = data.address.state || '';
              name = `${city}${state ? ', ' + state : ''}`;
            }
          } catch (e) {
            // fallback name is already set
          }

          setCurrentLocation({
            name,
            address: `GPS Coordinates: [${lat.toFixed(5)}, ${lng.toFixed(5)}]`,
            lat,
            lng,
            isGPS: true
          });
          setIsLocating(false);
          resolve({ lat, lng, name });
        },
        (error) => {
          setIsLocating(false);
          alert('GPS detection failed or permission denied: ' + error.message + '. Please use the manual location selector.');
          reject(error);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    });
  };

  return (
    <LocationContext.Provider
      value={{
        currentLocation,
        isLocating,
        locationModalOpen,
        setLocationModalOpen,
        setManualLocation,
        searchAndSetLocation,
        detectGPSLocation,
        presetLocations: PRESET_LOCATIONS
      }}
    >
      {children}
    </LocationContext.Provider>
  );
};

export const useLocation = () => useContext(LocationContext);
