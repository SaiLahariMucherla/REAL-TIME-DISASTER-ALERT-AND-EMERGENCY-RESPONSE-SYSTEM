import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { io } from 'socket.io-client';

const SocketContext = createContext(null);

export const SocketProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [connected, setConnected] = useState(false);
  const [latestBroadcast, setLatestBroadcast] = useState(null);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Synthesized Emergency Warning Siren via Web Audio API (100% reliable, zero external files)
  const playSirenSound = useCallback(() => {
    if (!soundEnabled) return;
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(400, ctx.currentTime + 0.3);
      osc.frequency.exponentialRampToValueAtTime(850, ctx.currentTime + 0.6);

      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.9);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.9);
    } catch (e) {
      console.warn('Audio playback not allowed without user gesture yet:', e);
    }
  }, [soundEnabled]);

  useEffect(() => {
    const s = io(window.location.origin, {
      transports: ['websocket', 'polling']
    });

    s.on('connect', () => {
      console.log('[Socket] Connected to server ID:', s.id);
      setConnected(true);
    });

    s.on('disconnect', () => {
      console.log('[Socket] Disconnected from server');
      setConnected(false);
    });

    s.on('emergency_broadcast', (data) => {
      console.log('[Socket] Emergency broadcast received:', data);
      setLatestBroadcast(data);
      playSirenSound();
    });

    setSocket(s);

    return () => {
      s.disconnect();
    };
  }, [playSirenSound]);

  const dismissBroadcast = () => {
    setLatestBroadcast(null);
  };

  const toggleSound = () => {
    setSoundEnabled(prev => !prev);
  };

  return (
    <SocketContext.Provider
      value={{
        socket,
        connected,
        latestBroadcast,
        dismissBroadcast,
        soundEnabled,
        toggleSound,
        playSirenSound
      }}
    >
      {children}
    </SocketContext.Provider>
  );
};

export const useSocket = () => useContext(SocketContext);
