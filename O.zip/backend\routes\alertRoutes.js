const express = require('express');
const router = express.Router();
const alertController = require('../controllers/alertController');
const { protect, requireAuthority } = require('../middleware/authMiddleware');

router.get('/', alertController.getAllAlerts);
router.get('/live-feeds', alertController.getLiveFeeds);
router.get('/:id', alertController.getAlertById);
router.post('/', protect, requireAuthority, alertController.createAlert);
router.put('/:id', protect, requireAuthority, alertController.updateAlert);
router.delete('/:id', protect, requireAuthority, alertController.deleteAlert);

module.exports = router;
