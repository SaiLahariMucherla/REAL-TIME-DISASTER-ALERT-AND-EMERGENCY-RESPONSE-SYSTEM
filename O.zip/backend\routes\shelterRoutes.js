const express = require('express');
const router = express.Router();
const shelterController = require('../controllers/shelterController');
const { protect, requireAuthority } = require('../middleware/authMiddleware');

router.get('/', shelterController.getAllShelters);
router.get('/hotlines', shelterController.getHotlines);
router.get('/:id', shelterController.getShelterById);
router.post('/', protect, requireAuthority, shelterController.createShelter);
router.patch('/:id/occupancy', protect, requireAuthority, shelterController.updateOccupancy);

module.exports = router;
