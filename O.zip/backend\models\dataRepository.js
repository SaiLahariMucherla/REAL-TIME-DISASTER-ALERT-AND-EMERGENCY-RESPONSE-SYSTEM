const { collections } = require('../services/storageAdapter');

// User Repository
const User = {
  find: async (filter = {}) => collections.users.find(filter),
  findOne: async (filter = {}) => collections.users.findOne(filter),
  findById: async (id) => collections.users.findById(id),
  create: async (data) => collections.users.create(data),
  findByIdAndUpdate: async (id, data) => collections.users.findByIdAndUpdate(id, data),
  countDocuments: async (filter = {}) => collections.users.countDocuments(filter)
};

// Alert Repository
const Alert = {
  find: async (filter = {}) => {
    let items = collections.alerts.find(filter);
    return items.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  },
  findOne: async (filter = {}) => collections.alerts.findOne(filter),
  findById: async (id) => collections.alerts.findById(id),
  create: async (data) => collections.alerts.create(data),
  findByIdAndUpdate: async (id, data) => collections.alerts.findByIdAndUpdate(id, data),
  findByIdAndDelete: async (id) => collections.alerts.findByIdAndDelete(id),
  countDocuments: async (filter = {}) => collections.alerts.countDocuments(filter)
};

// Incident Report Repository
const IncidentReport = {
  find: async (filter = {}) => {
    let items = collections.reports.find(filter);
    return items.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  },
  findOne: async (filter = {}) => collections.reports.findOne(filter),
  findById: async (id) => collections.reports.findById(id),
  create: async (data) => collections.reports.create(data),
  findByIdAndUpdate: async (id, data) => collections.reports.findByIdAndUpdate(id, data),
  findByIdAndDelete: async (id) => collections.reports.findByIdAndDelete(id),
  countDocuments: async (filter = {}) => collections.reports.countDocuments(filter)
};

// Shelter & Hospital Repository
const Shelter = {
  find: async (filter = {}) => collections.shelters.find(filter),
  findOne: async (filter = {}) => collections.shelters.findOne(filter),
  findById: async (id) => collections.shelters.findById(id),
  create: async (data) => collections.shelters.create(data),
  findByIdAndUpdate: async (id, data) => collections.shelters.findByIdAndUpdate(id, data),
  findByIdAndDelete: async (id) => collections.shelters.findByIdAndDelete(id),
  countDocuments: async (filter = {}) => collections.shelters.countDocuments(filter)
};

// Notification Log Repository
const NotificationLog = {
  find: async (filter = {}) => {
    let items = collections.notifications.find(filter);
    return items.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  },
  create: async (data) => collections.notifications.create(data),
  countDocuments: async (filter = {}) => collections.notifications.countDocuments(filter)
};

module.exports = {
  User,
  Alert,
  IncidentReport,
  Shelter,
  NotificationLog
};
