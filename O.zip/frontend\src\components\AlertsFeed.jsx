import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  Radio,
  Activity,
  CloudRain,
  Flame,
  Wind,
  Shield,
  Volume2,
  Navigation,
  ExternalLink,
  Clock,
  MapPin,
  RefreshCw
} from 'lucide-react';
import { alertService } from '../services/api';
import { useSocket } from '../context/SocketContext';

const AlertsFeed = ({ alerts = [], onNavigateToMap, onNavigateToEvac }) => {
  const [selectedSeverity, setSelectedSeverity] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [liveFeeds, setLiveFeeds] = useState(null);
  const [loadingFeeds, setLoadingFeeds] = useState(false);
  const { playSirenSound } = useSocket();

  const fetchLiveFeeds = async () => {
    try {
      setLoadingFeeds(true);
      const res = await alertService.getLiveFeeds({ lat: 17.385, lng: 78.486 });
      if (res.data.success) {
        setLiveFeeds(res.data.data);
      }
    } catch (err) {
      console.warn('Could not load live feeds:', err);
    } finally {
      setLoadingFeeds(false);
    }
  };

  useEffect(() => {
    fetchLiveFeeds();
  }, []);

  const filteredAlerts = alerts.filter(a => {
    if (selectedSeverity !== 'all' && a.severity !== selectedSeverity) return false;
    if (selectedType !== 'all' && a.type !== selectedType) return false;
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-red-400 text-xs font-mono font-bold uppercase tracking-wider mb-1">
            <Radio className="w-4 h-4 animate-pulse" />
            National Disaster Alert Feed
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Active Warning Advisories & Live Feeds
          </h1>
          <p className="text-sm text-slate-400">
            Real-time hazard detections verified by seismic monitoring agencies & meteorology services.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={playSirenSound}
            className="px-3.5 py-2 rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/30 text-xs font-bold flex items-center gap-2 transition-all"
          >
            <Volume2 className="w-4 h-4" />
            Test Siren Alarm
          </button>
          <button
            onClick={fetchLiveFeeds}
            disabled={loadingFeeds}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
            title="Refresh Live API Feeds"
          >
            <RefreshCw className={`w-4 h-4 ${loadingFeeds ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Live External API Feeds (USGS Earthquake & Weather) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* USGS Live Seismic Monitor */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <Activity className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-white text-sm">USGS Real-Time Seismic Feed</h3>
                <p className="text-[10px] text-slate-400">Global & Regional Earthquake Sensors</p>
              </div>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              API LIVE
            </span>
          </div>

          <div className="space-y-2 max-h-40 overflow-y-auto pr-1 text-xs">
            {liveFeeds?.earthquakes?.map((eq) => (
              <div key={eq.id} className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-semibold text-slate-200">{eq.title}</div>
                  <div className="text-[10px] text-slate-400 font-mono">Depth: {eq.depthKm} km • {new Date(eq.time).toLocaleTimeString()}</div>
                </div>
                <span className={`px-2 py-1 rounded text-xs font-black font-mono ${
                  eq.magnitude >= 6 ? 'bg-red-500/20 text-red-400' : 'bg-amber-500/20 text-amber-400'
                }`}>
                  M {eq.magnitude}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Live Weather Forecast / Open-Meteo */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
                <CloudRain className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-white text-sm">Open-Meteo Weather Radar</h3>
                <p className="text-[10px] text-slate-400">Meteorological Storm & Wind Tracking</p>
              </div>
            </div>
            <span className="text-[10px] font-mono text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
              SYNCHRONIZED
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
              <div className="text-[10px] text-slate-400 font-mono uppercase">Surface Temp</div>
              <div className="text-xl font-black text-white mt-1">{liveFeeds?.weather?.temperature ?? 29}°C</div>
            </div>
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
              <div className="text-[10px] text-slate-400 font-mono uppercase">Wind Speed</div>
              <div className="text-xl font-black text-orange-400 mt-1">{liveFeeds?.weather?.windspeed ?? 42} <span className="text-xs font-normal">km/h</span></div>
            </div>
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
              <div className="text-[10px] text-slate-400 font-mono uppercase">Squall Index</div>
              <div className="text-xl font-black text-red-400 mt-1">Severe</div>
            </div>
          </div>
          <div className="text-[11px] text-slate-400 mt-3 p-2 bg-slate-950/40 rounded-xl border border-slate-800/80">
            ℹ️ Monitored station: Hyderabad / Bay of Bengal basin. High gust activity detected along coastal corridors.
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-3 rounded-2xl">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider mr-2 font-mono">Severity:</span>
          {['all', 'critical', 'high', 'moderate'].map((sev) => (
            <button
              key={sev}
              onClick={() => setSelectedSeverity(sev)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all ${
                selectedSeverity === sev
                  ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                  : 'text-slate-400 hover:text-white bg-slate-950'
              }`}
            >
              {sev}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider mr-2 font-mono">Disaster:</span>
          {['all', 'cyclone', 'flood', 'earthquake', 'wildfire'].map((t) => (
            <button
              key={t}
              onClick={() => setSelectedType(t)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all ${
                selectedType === t
                  ? 'bg-slate-700 text-white'
                  : 'text-slate-400 hover:text-white bg-slate-950'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Alerts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredAlerts.map((alert) => {
          const isCritical = alert.severity === 'critical';
          const isHigh = alert.severity === 'high';

          return (
            <div
              key={alert._id || alert.id}
              className={`rounded-3xl p-5 border flex flex-col justify-between transition-all ${
                isCritical
                  ? 'bg-red-950/20 border-red-500/40 shadow-xl shadow-red-950/20'
                  : isHigh
                  ? 'bg-orange-950/20 border-orange-500/40'
                  : 'bg-slate-900 border-slate-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full text-white ${
                      isCritical ? 'bg-red-600 animate-pulse' : isHigh ? 'bg-orange-500' : 'bg-yellow-500 text-black'
                    }`}>
                      {alert.severity}
                    </span>
                    <span className="text-xs font-bold text-slate-300 uppercase font-mono">
                      {alert.type}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500">
                    {new Date(alert.issuedAt).toLocaleTimeString()}
                  </span>
                </div>

                <h3 className="text-base font-black text-white leading-snug mb-1.5">{alert.title}</h3>
                <p className="text-xs text-slate-300 leading-relaxed mb-3">{alert.description}</p>

                <div className="flex items-center gap-2 text-xs text-slate-400 font-mono mb-3 bg-slate-950/60 p-2 rounded-xl border border-slate-800">
                  <MapPin className="w-3.5 h-3.5 text-red-400 shrink-0" />
                  <span>Region: <strong className="text-slate-200">{alert.location.area}</strong> ({alert.location.radiusKm} km radius)</span>
                </div>

                {alert.instructions && alert.instructions.length > 0 && (
                  <div className="space-y-1 mb-4">
                    <div className="text-[10px] font-bold uppercase text-red-400 font-mono">Mandatory Precautions:</div>
                    {alert.instructions.slice(0, 3).map((ins, i) => (
                      <div key={i} className="text-xs text-slate-300 flex items-start gap-1.5">
                        <span className="text-red-400 font-bold">•</span>
                        <span>{ins}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                <span className="text-[10px] text-slate-500 truncate max-w-[150px]">
                  Source: {alert.source}
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onNavigateToMap && onNavigateToMap(alert)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-1 border border-slate-700"
                  >
                    <MapPin className="w-3 h-3 text-red-400" />
                    Map Pin
                  </button>
                  <button
                    onClick={() => onNavigateToEvac && onNavigateToEvac()}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white flex items-center gap-1 shadow-md shadow-emerald-600/20"
                  >
                    <Navigation className="w-3 h-3" />
                    Safe Route
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AlertsFeed;
