import axios from 'axios';

const api = axios.create({
  baseURL: '/api'
});

// Attach JWT token to requests if available
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('resq_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

export const alertService = {
  getAll: (params) => api.get('/alerts', { params }),
  getById: (id) => api.get(`/alerts/${id}`),
  create: (data) => api.post('/alerts', data),
  update: (id, data) => api.put(`/alerts/${id}`, data),
  delete: (id) => api.delete(`/alerts/${id}`),
  getLiveFeeds: (params) => api.get('/alerts/live-feeds', { params })
};

export const reportService = {
  getAll: (params) => api.get('/reports', { params }),
  create: (formData) => api.post('/reports', formData),
  updateStatus: (id, data) => api.patch(`/reports/${id}/status`, data),
  delete: (id) => api.delete(`/reports/${id}`)
};

export const shelterService = {
  getAll: (params) => api.get('/shelters', { params }),
  getById: (id) => api.get(`/shelters/${id}`),
  getHotlines: () => api.get('/shelters/hotlines'),
  create: (data) => api.post('/shelters', data),
  updateOccupancy: (id, data) => api.patch(`/shelters/${id}/occupancy`, data)
};

export const statsService = {
  getDashboard: () => api.get('/stats')
};

export const authService = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  quickDemo: (role) => api.post(`/auth/demo/${role}`),
  getMe: () => api.get('/auth/me')
};

export default api;
