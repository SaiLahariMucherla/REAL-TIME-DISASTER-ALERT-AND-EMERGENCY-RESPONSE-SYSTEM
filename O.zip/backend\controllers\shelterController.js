const { Shelter } = require('../models/dataRepository');
const config = require('../config/config');

// Calculate Haversine distance in km
function calculateDistanceKm(lat1, lon1, lat2, lon2) {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round((R * c) * 10) / 10;
}

// Helper to generate localized emergency shelters in any city worldwide
function generateLocalShelters(cityName, lat, lng) {
  const cleanCity = cityName ? cityName.split(',')[0].trim() : 'Local District';
  return [
    {
      name: `${cleanCity} District Civil Hospital & Trauma Center`,
      type: 'hospital',
      location: {
        address: `Hospital Road, Civil Lines, ${cleanCity}`,
        city: cleanCity,
        lat: Math.round((lat + 0.012) * 10000) / 10000,
        lng: Math.round((lng + 0.009) * 10000) / 10000
      },
      totalCapacity: 450,
      currentOccupancy: 180,
      availableBeds: 270,
      hasMedicalAid: true,
      hasFoodWater: true,
      contactPhone: '108',
      status: 'open'
    },
    {
      name: `${cleanCity} Municipal Disaster Evacuation Center & Stadium`,
      type: 'shelter',
      location: {
        address: `Sports Complex, Sector 4, ${cleanCity}`,
        city: cleanCity,
        lat: Math.round((lat - 0.014) * 10000) / 10000,
        lng: Math.round((lng + 0.012) * 10000) / 10000
      },
      totalCapacity: 800,
      currentOccupancy: 210,
      availableBeds: 590,
      hasMedicalAid: true,
      hasFoodWater: true,
      contactPhone: '1078',
      status: 'open'
    },
    {
      name: `Red Cross Emergency Relief Shelter - ${cleanCity}`,
      type: 'shelter',
      location: {
        address: `Red Cross Compound, Station Road, ${cleanCity}`,
        city: cleanCity,
        lat: Math.round((lat + 0.018) * 10000) / 10000,
        lng: Math.round((lng - 0.015) * 10000) / 10000
      },
      totalCapacity: 350,
      currentOccupancy: 85,
      availableBeds: 265,
      hasMedicalAid: true,
      hasFoodWater: true,
      contactPhone: '112',
      status: 'open'
    },
    {
      name: `${cleanCity} Emergency Multi-Specialty Health Outpost`,
      type: 'hospital',
      location: {
        address: `Near National Highway Junction, ${cleanCity}`,
        city: cleanCity,
        lat: Math.round((lat - 0.011) * 10000) / 10000,
        lng: Math.round((lng - 0.013) * 10000) / 10000
      },
      totalCapacity: 250,
      currentOccupancy: 140,
      availableBeds: 110,
      hasMedicalAid: true,
      hasFoodWater: true,
      contactPhone: '108',
      status: 'open'
    }
  ];
}

// Get all shelters / hospitals
exports.getAllShelters = async (req, res) => {
  try {
    const { type, userLat, userLng, cityName, maxDistance } = req.query;
    let shelters = await Shelter.find();

    if (userLat && userLng) {
      const uLat = parseFloat(userLat);
      const uLng = parseFloat(userLng);

      // Check if any shelter is within 35 km
      let nearby = shelters.filter(s => calculateDistanceKm(uLat, uLng, s.location.lat, s.location.lng) <= 35);

      // If no shelters nearby in this city/coordinates, auto-provision local shelters
      if (nearby.length === 0) {
        const generated = generateLocalShelters(cityName, uLat, uLng);
        for (const gen of generated) {
          const created = await Shelter.create(gen);
          shelters.push(created);
        }
      }

      shelters = shelters.map(s => {
        const distanceKm = calculateDistanceKm(uLat, uLng, s.location.lat, s.location.lng);
        return {
          ...s,
          distanceKm
        };
      });

      shelters.sort((a, b) => a.distanceKm - b.distanceKm);

      if (maxDistance) {
        const maxDist = parseFloat(maxDistance);
        shelters = shelters.filter(s => s.distanceKm <= maxDist);
      }
    }

    if (type && type !== 'all') {
      shelters = shelters.filter(s => s.type === type.toLowerCase());
    }

    return res.json({
      success: true,
      count: shelters.length,
      shelters
    });
  } catch (error) {
    console.error('[shelterController.getAllShelters]', error);
    return res.status(500).json({ success: false, message: 'Failed to retrieve shelters' });
  }
};

// Get single shelter
exports.getShelterById = async (req, res) => {
  try {
    const shelter = await Shelter.findById(req.params.id);
    if (!shelter) {
      return res.status(404).json({ success: false, message: 'Shelter not found' });
    }
    return res.json({ success: true, shelter });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Error fetching shelter' });
  }
};

// Create or register new shelter (Authority only)
exports.createShelter = async (req, res) => {
  try {
    const {
      name,
      type,
      location,
      totalCapacity,
      currentOccupancy,
      hasMedicalAid,
      hasFoodWater,
      contactPhone
    } = req.body;

    if (!name || !location || !location.address || !location.lat || !location.lng) {
      return res.status(400).json({ success: false, message: 'Shelter name and GPS location required.' });
    }

    const totalCap = totalCapacity ? parseInt(totalCapacity, 10) : 500;
    const occ = currentOccupancy ? parseInt(currentOccupancy, 10) : 0;

    const newShelter = await Shelter.create({
      name,
      type: type || 'shelter',
      location: {
        address: location.address,
        city: location.city || 'Emergency Zone',
        lat: parseFloat(location.lat),
        lng: parseFloat(location.lng)
      },
      totalCapacity: totalCap,
      currentOccupancy: occ,
      availableBeds: Math.max(0, totalCap - occ),
      hasMedicalAid: hasMedicalAid !== undefined ? Boolean(hasMedicalAid) : true,
      hasFoodWater: hasFoodWater !== undefined ? Boolean(hasFoodWater) : true,
      contactPhone: contactPhone || '1078',
      status: occ >= totalCap ? 'full' : 'open'
    });

    return res.status(201).json({ success: true, shelter: newShelter });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Failed to create shelter' });
  }
};

// Update occupancy
exports.updateOccupancy = async (req, res) => {
  try {
    const { currentOccupancy, status } = req.body;
    const shelter = await Shelter.findById(req.params.id);

    if (!shelter) {
      return res.status(404).json({ success: false, message: 'Shelter not found' });
    }

    const occ = currentOccupancy !== undefined ? parseInt(currentOccupancy, 10) : shelter.currentOccupancy;
    const available = Math.max(0, shelter.totalCapacity - occ);

    const updated = await Shelter.findByIdAndUpdate(req.params.id, {
      currentOccupancy: occ,
      availableBeds: available,
      status: status || (occ >= shelter.totalCapacity ? 'full' : 'open')
    });

    return res.json({ success: true, shelter: updated });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Failed to update shelter occupancy' });
  }
};

// Get emergency hotlines
exports.getHotlines = (req, res) => {
  return res.json({
    success: true,
    hotlines: config.DISASTER_HOTLINES
  });
};
