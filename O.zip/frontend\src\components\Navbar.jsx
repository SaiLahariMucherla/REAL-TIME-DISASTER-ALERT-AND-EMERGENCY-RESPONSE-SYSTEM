import React from 'react';
import {
  AlertTriangle,
  Radio,
  MapPin,
  Shield,
  LifeBuoy,
  Volume2,
  VolumeX,
  PhoneCall,
  User,
  LogOut,
  Navigation,
  BookOpen,
  Globe,
  FileText
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { useLocation } from '../context/LocationContext';

const Navbar = ({ activeTab, setActiveTab, onOpenReportModal, onOpenAuthModal }) => {
  const { user, isAuthority, logout, quickDemoLogin } = useAuth();
  const { connected, soundEnabled, toggleSound } = useSocket();
  const { currentLocation, setLocationModalOpen } = useLocation();

  return (
    <header className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
      {/* Emergency Ticker Banner */}
      <div className="bg-red-950/80 border-b border-red-800/40 px-4 py-1.5 text-xs flex items-center justify-between text-red-200">
        <div className="flex items-center gap-2 overflow-hidden whitespace-nowrap">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
          </span>
          <span className="font-bold tracking-wider text-red-400 uppercase text-[10px]">LIVE SOS TICKER:</span>
          <span className="animate-marquee font-medium text-slate-200">
            ⚠️ Severe Cyclone "Varun" coastal alert active • Flash flood warning in Godavari/Musi lowlands • Emergency helplines 112 & 1078 active 24/7.
          </span>
        </div>
        <div className="hidden md:flex items-center gap-4 text-[11px] shrink-0 font-mono">
          {/* Active Global Location Indicator in Top Bar */}
          <button
            onClick={() => setLocationModalOpen(true)}
            className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-blue-950/60 hover:bg-blue-900 text-blue-300 border border-blue-500/40 transition-colors"
            title="Click to search any location worldwide or auto-detect GPS"
          >
            <Globe className="w-3 h-3 text-blue-400" />
            <span>📍 {currentLocation.name.split(',')[0]} (Change)</span>
          </button>

          <span className="flex items-center gap-1.5 text-slate-400">
            <span className={`w-2 h-2 rounded-full ${connected ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
            {connected ? 'WS LIVE' : 'WS CONNECTING...'}
          </span>
          <a
            href="tel:112"
            className="flex items-center gap-1 px-2.5 py-0.5 rounded bg-red-600 text-white font-bold hover:bg-red-500 transition-colors"
          >
            <PhoneCall className="w-3 h-3" />
            DIAL 112
          </a>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('map')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-red-600 to-orange-500 flex items-center justify-center shadow-lg shadow-red-500/20">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-tight text-white">ResQ<span className="text-red-500">Alert</span></span>
                <span className="text-[10px] font-semibold uppercase tracking-wider bg-red-500/10 text-red-400 border border-red-500/20 px-1.5 py-0.5 rounded">
                  v2.0
                </span>
              </div>
              <p className="text-[10px] text-slate-400 hidden sm:block">National Disaster Warning & Emergency Grid</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            <button
              onClick={() => setActiveTab('map')}
              className={`px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors ${
                activeTab === 'map'
                  ? 'bg-slate-800 text-red-400 border border-slate-700'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <MapPin className="w-4 h-4 text-red-400" />
              Live Map
            </button>

            <button
              onClick={() => setActiveTab('alerts')}
              className={`px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors ${
                activeTab === 'alerts'
                  ? 'bg-slate-800 text-red-400 border border-slate-700'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <Radio className="w-4 h-4 text-orange-400" />
              Disaster Alerts
            </button>

            <button
              onClick={() => setActiveTab('evac')}
              className={`px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors ${
                activeTab === 'evac'
                  ? 'bg-slate-800 text-red-400 border border-slate-700'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <Navigation className="w-4 h-4 text-emerald-400" />
              Evacuation Routes
            </button>

            <button
              onClick={() => setActiveTab('shelters')}
              className={`px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors ${
                activeTab === 'shelters'
                  ? 'bg-slate-800 text-red-400 border border-slate-700'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <LifeBuoy className="w-4 h-4 text-blue-400" />
              Shelters & Medical
            </button>

            {/* Victim SOS Status Tracker */}
            <button
              onClick={() => setActiveTab('tracker')}
              className={`px-3 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-colors ${
                activeTab === 'tracker'
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <FileText className="w-4 h-4 text-amber-400" />
              <span>Track SOS Status</span>
            </button>

            <button
              onClick={() => setActiveTab('guides')}
              className={`px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors ${
                activeTab === 'guides'
                  ? 'bg-slate-800 text-red-400 border border-slate-700'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <BookOpen className="w-4 h-4 text-purple-400" />
              Survival Guides
            </button>

            {isAuthority && (
              <button
                onClick={() => setActiveTab('admin')}
                className={`px-3 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-colors ${
                  activeTab === 'admin'
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                    : 'text-amber-400 hover:bg-amber-500/10'
                }`}
              >
                <Shield className="w-4 h-4" />
                Command Center
              </button>
            )}
          </nav>

          {/* Action CTAs & Auth */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Audio Siren Toggle */}
            <button
              onClick={toggleSound}
              title={soundEnabled ? 'Emergency Siren Audio Enabled' : 'Siren Muted'}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors border border-slate-700"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
            </button>

            {/* SOS Emergency Report Button */}
            <button
              onClick={onOpenReportModal}
              className="px-3.5 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-red-600/30 transition-all hover:scale-105 active:scale-95"
            >
              <AlertTriangle className="w-4 h-4 animate-bounce" />
              <span>Report SOS</span>
            </button>

            {/* Quick Demo Switcher / Profile */}
            {user ? (
              <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
                <div className="hidden sm:block text-right">
                  <div className="text-xs font-semibold text-slate-200 leading-tight truncate max-w-[120px]">
                    {user.name}
                  </div>
                  <div className="text-[10px] font-mono text-emerald-400 uppercase">
                    {user.role === 'authority' ? 'Authority Officer' : 'Citizen'}
                  </div>
                </div>
                <button
                  onClick={logout}
                  title="Logout"
                  className="p-2 rounded-lg bg-slate-800 hover:bg-red-950/60 hover:text-red-400 text-slate-400 border border-slate-700 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => quickDemoLogin('authority')}
                  className="hidden sm:inline-flex px-2.5 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold"
                  title="Login as Response Officer with full admin privileges"
                >
                  Officer Demo
                </button>
                <button
                  onClick={onOpenAuthModal}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-sm font-medium flex items-center gap-1.5"
                >
                  <User className="w-3.5 h-3.5" />
                  <span>Login</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Mobile Sub-Navigation Bar */}
        <div className="lg:hidden flex items-center justify-around py-2 border-t border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('map')}
            className={`py-1 px-2 rounded ${activeTab === 'map' ? 'text-red-400 font-bold' : 'text-slate-400'}`}
          >
            Map
          </button>
          <button
            onClick={() => setActiveTab('alerts')}
            className={`py-1 px-2 rounded ${activeTab === 'alerts' ? 'text-red-400 font-bold' : 'text-slate-400'}`}
          >
            Alerts
          </button>
          <button
            onClick={() => setActiveTab('evac')}
            className={`py-1 px-2 rounded ${activeTab === 'evac' ? 'text-red-400 font-bold' : 'text-slate-400'}`}
          >
            Evac Route
          </button>
          <button
            onClick={() => setActiveTab('shelters')}
            className={`py-1 px-2 rounded ${activeTab === 'shelters' ? 'text-red-400 font-bold' : 'text-slate-400'}`}
          >
            Shelters
          </button>
          <button
            onClick={() => setActiveTab('tracker')}
            className={`py-1 px-2 rounded ${activeTab === 'tracker' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
          >
            Track SOS
          </button>
          <button
            onClick={() => setActiveTab('guides')}
            className={`py-1 px-2 rounded ${activeTab === 'guides' ? 'text-red-400 font-bold' : 'text-slate-400'}`}
          >
            Guides
          </button>
          {isAuthority && (
            <button
              onClick={() => setActiveTab('admin')}
              className={`py-1 px-2 rounded ${activeTab === 'admin' ? 'text-amber-400 font-bold' : 'text-slate-400'}`}
            >
              Command
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

export default Navbar;
