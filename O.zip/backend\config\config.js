const path = require('path');
require('dotenv').config();

module.exports = {
  PORT: process.env.PORT || 5000,
  MONGODB_URI: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/disaster_response_db',
  JWT_SECRET: process.env.JWT_SECRET || 'disaster_response_super_secret_jwt_key_2026',
  JWT_EXPIRES_IN: '7d',
  DATA_DIR: path.join(__dirname, '../data'),
  UPLOADS_DIR: path.join(__dirname, '../uploads'),
  DISASTER_HOTLINES: [
    { name: 'National Emergency Number', number: '112', type: 'All-in-one' },
    { name: 'National Disaster Response Force (NDRF)', number: '1078', type: 'Disaster' },
    { name: 'Ambulance / Medical Emergency', number: '108', type: 'Medical' },
    { name: 'Fire & Rescue Service', number: '101', type: 'Fire' },
    { name: 'Police Assistance', number: '100', type: 'Police' },
    { name: 'Women Safety Helpline', number: '1091', type: 'Support' }
  ]
};
