const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('../config/config');
const { User } = require('../models/dataRepository');

// Generate JWT token
const generateToken = (user) => {
  return jwt.sign(
    {
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role
    },
    config.JWT_SECRET,
    { expiresIn: config.JWT_EXPIRES_IN }
  );
};

// Register
exports.register = async (req, res) => {
  try {
    const { name, email, password, phone, role, location } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ success: false, message: 'Please provide name, email, and password.' });
    }

    const existingUser = await User.findOne({ email: email.toLowerCase().trim() });
    if (existingUser) {
      return res.status(400).json({ success: false, message: 'An account with this email already exists.' });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const newUser = await User.create({
      name,
      email: email.toLowerCase().trim(),
      password: hashedPassword,
      phone: phone || '',
      role: role === 'authority' ? 'authority' : 'citizen',
      location: location || { city: 'Default', lat: 17.385, lng: 78.486 }
    });

    const token = generateToken(newUser);

    return res.status(201).json({
      success: true,
      message: 'Registration successful',
      token,
      user: {
        id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        phone: newUser.phone,
        location: newUser.location
      }
    });
  } catch (error) {
    console.error('[authController.register]', error);
    return res.status(500).json({ success: false, message: 'Server error during registration' });
  }
};

// Login
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Please provide email and password.' });
    }

    const user = await User.findOne({ email: email.toLowerCase().trim() });
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const token = generateToken(user);

    return res.json({
      success: true,
      message: 'Login successful',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        location: user.location
      }
    });
  } catch (error) {
    console.error('[authController.login]', error);
    return res.status(500).json({ success: false, message: 'Server error during login' });
  }
};

// Quick Demo Login (for examiners & easy review)
exports.quickDemoLogin = async (req, res) => {
  try {
    const { role } = req.params; // 'citizen' or 'authority'
    const targetEmail = role === 'authority' ? 'officer@disaster-response.gov' : 'citizen@example.com';

    let user = await User.findOne({ email: targetEmail });
    if (!user) {
      // Create if missing
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash('DemoPass123!', salt);
      user = await User.create({
        name: role === 'authority' ? 'Chief Disaster Response Commander' : 'Demo Resident (Citizen)',
        email: targetEmail,
        password: hashedPassword,
        phone: role === 'authority' ? '+91-9876543210' : '+91-9123456789',
        role: role === 'authority' ? 'authority' : 'citizen',
        location: { city: 'Hyderabad', lat: 17.385, lng: 78.486 }
      });
    }

    const token = generateToken(user);
    return res.json({
      success: true,
      message: `Demo logged in as ${user.role.toUpperCase()}`,
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        location: user.location
      }
    });
  } catch (error) {
    console.error('[authController.quickDemoLogin]', error);
    return res.status(500).json({ success: false, message: 'Server error during demo login' });
  }
};

// Get current user profile
exports.getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    return res.json({
      success: true,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        location: user.location
      }
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Server error fetching user profile' });
  }
};
