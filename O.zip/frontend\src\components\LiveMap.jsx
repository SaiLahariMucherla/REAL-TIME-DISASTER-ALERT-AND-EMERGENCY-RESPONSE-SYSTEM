import React, { useState, useEffect } from 'react';
import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  Circle,
  useMap,
  useMapEvents
} from 'react-leaflet';
import L from 'leaflet';
import {
  AlertTriangle,
  LifeBuoy,
  Hospital,
  MapPin,
  Crosshair,
  Layers,
  ShieldAlert,
  Flame,
  Wind,
  Waves,
  Activity,
  CheckCircle2,
  Navigation2,
  Globe,
  Search
} from 'lucide-react';
import { useLocation } from '../context/LocationContext';

// Click on map to set user location
function MapClickHandler({ onMapClick }) {
  useMapEvents({
    click(e) {
      if (onMapClick) onMapClick(e.latlng);
    }
  });
  return null;
}

// Fix default Leaflet icon paths
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png'
});

// Custom SVG Markers
const createCustomIcon = (color, symbol) => {
  return L.divIcon({
    className: 'custom-leaflet-marker',
    html: `
      <div style="
        background-color: ${color};
        width: 34px;
        height: 34px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 0 12px ${color}88, 0 2px 4px rgba(0,0,0,0.5);
        border: 2px solid #ffffff;
        color: white;
        font-weight: bold;
        font-size: 16px;
      ">
        ${symbol}
      </div>
    `,
    iconSize: [34, 34],
    iconAnchor: [17, 17],
    popupAnchor: [0, -17]
  });
};

const userIcon = L.divIcon({
  className: 'user-marker',
  html: `
    <div style="
      background-color: #3b82f6;
      width: 24px;
      height: 24px;
      border-radius: 50%;
      border: 3px solid #ffffff;
      box-shadow: 0 0 16px #3b82f6, 0 0 0 8px rgba(59, 130, 246, 0.3);
    "></div>
  `,
  iconSize: [24, 24],
  iconAnchor: [12, 12]
});

// Helper component to center map on coordinates
function ChangeView({ center, zoom }) {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.setView(center, zoom || map.getZoom());
    }
  }, [center, zoom, map]);
  return null;
}

const LiveMap = ({ alerts = [], shelters = [], reports = [], onSelectForEvac }) => {
  const {
    currentLocation,
    setManualLocation,
    setLocationModalOpen,
    detectGPSLocation,
    isLocating
  } = useLocation();

  const [mapCenter, setMapCenter] = useState([currentLocation.lat, currentLocation.lng]);
  const [filterLayer, setFilterLayer] = useState({
    alerts: true,
    shelters: true,
    reports: true
  });
  const [clickNotice, setClickNotice] = useState('');

  // Sync map center whenever global location changes
  useEffect(() => {
    setMapCenter([currentLocation.lat, currentLocation.lng]);
  }, [currentLocation]);

  // Map Click Handler: allows victim/user to click ANYWHERE in the world to set their location
  const handleMapClick = (latlng) => {
    const lat = latlng.lat;
    const lng = latlng.lng;
    setManualLocation(
      `Custom Map Pin (${lat.toFixed(3)}, ${lng.toFixed(3)})`,
      lat,
      lng,
      `Map Location: [${lat.toFixed(4)}, ${lng.toFixed(4)}]`
    );
    setClickNotice(`Location set to [${lat.toFixed(4)}, ${lng.toFixed(4)}]`);
    setTimeout(() => setClickNotice(''), 4000);
  };

  const handleLocateMe = async () => {
    try {
      await detectGPSLocation();
    } catch (e) {}
  };

  const getAlertColor = (severity) => {
    switch (severity) {
      case 'critical': return '#ef4444';
      case 'high': return '#f97316';
      case 'moderate': return '#eab308';
      default: return '#3b82f6';
    }
  };

  const getDisasterIcon = (type) => {
    switch (type) {
      case 'flood': return '🌊';
      case 'cyclone': return '🌀';
      case 'earthquake': return '⚡';
      case 'wildfire': return '🔥';
      case 'landslide': return '⛰️';
      default: return '⚠️';
    }
  };

  return (
    <div className="relative w-full h-[calc(100vh-8.5rem)] min-h-[550px] rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl flex flex-col">
      {/* Top Map HUD Bar */}
      <div className="absolute top-4 left-4 z-[400] flex flex-wrap items-center gap-2 bg-slate-900/95 backdrop-blur-md px-3 py-2 rounded-xl border border-slate-800 shadow-xl text-xs">
        {/* Set / Change Location Button */}
        <button
          onClick={() => setLocationModalOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/40 font-bold transition-all shadow-md active:scale-95"
          title="Click to search any city worldwide or set custom coordinates"
        >
          <Globe className="w-3.5 h-3.5 text-blue-400" />
          <span>📍 {currentLocation.name.split(',')[0]} (Change)</span>
        </button>

        <button
          onClick={handleLocateMe}
          disabled={isLocating}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold transition-all active:scale-95 disabled:opacity-50"
        >
          <Crosshair className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin text-blue-400' : ''}`} />
          {isLocating ? 'Detecting...' : 'Auto GPS'}
        </button>

        <div className="h-4 w-[1px] bg-slate-700 hidden sm:block" />

        {/* Layer Filters */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setFilterLayer(prev => ({ ...prev, alerts: !prev.alerts }))}
            className={`px-2.5 py-1.5 rounded-lg font-medium transition-colors ${
              filterLayer.alerts
                ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                : 'text-slate-500 bg-slate-800/40'
            }`}
          >
            ⚠️ Hazard Zones ({alerts.filter(a => a.active).length})
          </button>
          <button
            onClick={() => setFilterLayer(prev => ({ ...prev, shelters: !prev.shelters }))}
            className={`px-2.5 py-1.5 rounded-lg font-medium transition-colors ${
              filterLayer.shelters
                ? 'bg-blue-500/20 text-blue-400 border border-blue-500/40'
                : 'text-slate-500 bg-slate-800/40'
            }`}
          >
            🏥 Shelters ({shelters.length})
          </button>
          <button
            onClick={() => setFilterLayer(prev => ({ ...prev, reports: !prev.reports }))}
            className={`px-2.5 py-1.5 rounded-lg font-medium transition-colors ${
              filterLayer.reports
                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                : 'text-slate-500 bg-slate-800/40'
            }`}
          >
            🚨 Citizen SOS ({reports.length})
          </button>
        </div>
      </div>

      {/* Map Click Notice Banner */}
      {clickNotice && (
        <div className="absolute top-16 left-4 z-[400] bg-emerald-950/90 border border-emerald-500/40 text-emerald-300 px-3.5 py-1.5 rounded-xl text-xs font-mono shadow-xl animate-fade-in flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span>{clickNotice}</span>
        </div>
      )}

      {/* Floating Tactical Legend */}
      <div className="absolute bottom-6 left-4 z-[400] hidden md:block bg-slate-900/90 backdrop-blur-md p-3.5 rounded-xl border border-slate-800 shadow-xl text-xs max-w-xs">
        <div className="font-bold text-slate-200 mb-2 flex items-center gap-1.5">
          <Layers className="w-3.5 h-3.5 text-slate-400" />
          Tactical Map Legend
        </div>
        <div className="space-y-1.5 text-[11px] text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-red-500 shadow-sm shadow-red-500/50" />
            <span>Critical Hazard Zone (Immediate Evacuation)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-orange-500 shadow-sm shadow-orange-500/50" />
            <span>High Risk Impact Zone (Advisory Warning)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-blue-500" />
            <span>Safe Emergency Shelter / Hospital Haven</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-amber-500" />
            <span>Active Citizen SOS Incident Pin</span>
          </div>
          <div className="pt-1 text-[10px] text-blue-400 font-mono">
            💡 Tip: Click anywhere on map to drop pin & set location
          </div>
        </div>
      </div>

      {/* Actual Map */}
      <MapContainer
        center={mapCenter}
        zoom={12}
        scrollWheelZoom={true}
        className="flex-1 w-full h-full z-10"
      >
        <ChangeView center={mapCenter} />
        <MapClickHandler onMapClick={handleMapClick} />

        {/* High-Contrast OpenStreetMap Layer with Dark Tile Option */}
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {/* User GPS Location Marker */}
        {currentLocation && (
          <Marker position={[currentLocation.lat, currentLocation.lng]} icon={userIcon}>
            <Popup>
              <div className="p-1 text-slate-900 font-sans">
                <div className="font-bold text-blue-600 flex items-center gap-1">
                  <MapPin className="w-4 h-4" /> Your Active Position
                </div>
                <div className="text-xs font-semibold text-slate-800 mt-1">
                  {currentLocation.name}
                </div>
                <div className="text-xs text-slate-600 font-mono mt-0.5">
                  Lat: {currentLocation.lat.toFixed(4)}, Lng: {currentLocation.lng.toFixed(4)}
                </div>
                <div className="text-[10px] text-blue-700 italic mt-1.5">
                  Click anywhere on the map to move your location!
                </div>
              </div>
            </Popup>
          </Marker>
        )}

        {/* Active Disaster Danger Radius Circles & Center Markers */}
        {filterLayer.alerts && alerts.filter(a => a.active).map(alert => {
          const color = getAlertColor(alert.severity);
          const icon = createCustomIcon(color, getDisasterIcon(alert.type));
          const radiusMeters = (alert.location.radiusKm || 15) * 1000;

          return (
            <React.Fragment key={alert._id || alert.id}>
              {/* Danger Radius Circle */}
              <Circle
                center={[alert.location.lat, alert.location.lng]}
                radius={radiusMeters}
                pathOptions={{
                  color: color,
                  fillColor: color,
                  fillOpacity: alert.severity === 'critical' ? 0.22 : 0.15,
                  weight: 2,
                  dashArray: alert.severity === 'critical' ? '6, 8' : undefined
                }}
              />

              {/* Epicenter Marker */}
              <Marker
                position={[alert.location.lat, alert.location.lng]}
                icon={icon}
              >
                <Popup>
                  <div className="p-2 max-w-xs text-slate-100 font-sans">
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded text-white ${
                        alert.severity === 'critical' ? 'bg-red-600' : 'bg-orange-500'
                      }`}>
                        {alert.severity}
                      </span>
                      <span className="text-xs text-slate-400 capitalize">{alert.type} Alert</span>
                    </div>
                    <h3 className="font-bold text-sm text-white leading-tight mb-1">{alert.title}</h3>
                    <p className="text-xs text-slate-300 mb-2 leading-relaxed">{alert.description}</p>
                    <div className="text-[11px] text-amber-400 font-medium bg-amber-500/10 p-1.5 rounded border border-amber-500/20 mb-2">
                      📍 Danger Perimeter: {alert.location.radiusKm || 15} km radius
                    </div>
                    {alert.instructions && alert.instructions.length > 0 && (
                      <div className="text-[11px] text-slate-300">
                        <strong className="text-red-400">Survival Action:</strong> {alert.instructions[0]}
                      </div>
                    )}
                  </div>
                </Popup>
              </Marker>
            </React.Fragment>
          );
        })}

        {/* Shelters & Hospitals */}
        {filterLayer.shelters && shelters.map(shelter => {
          const isHospital = shelter.type === 'hospital';
          const icon = createCustomIcon(
            isHospital ? '#059669' : '#2563eb',
            isHospital ? '🏥' : '🛡️'
          );

          return (
            <Marker
              key={shelter._id || shelter.id}
              position={[shelter.location.lat, shelter.location.lng]}
              icon={icon}
            >
              <Popup>
                <div className="p-2 max-w-xs text-slate-100 font-sans">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      {isHospital ? 'Emergency Hospital' : 'Safe Shelter'}
                    </span>
                    <span className="text-xs font-mono font-bold text-emerald-400">
                      {shelter.availableBeds} Beds Free
                    </span>
                  </div>
                  <h3 className="font-bold text-sm text-white leading-tight mb-1">{shelter.name}</h3>
                  <p className="text-xs text-slate-400 mb-2">{shelter.location.address}</p>
                  
                  <div className="grid grid-cols-2 gap-1 text-[11px] mb-3">
                    <div className="bg-slate-800 p-1 rounded text-slate-300">
                      Capacity: <span className="font-bold">{shelter.totalCapacity}</span>
                    </div>
                    <div className="bg-slate-800 p-1 rounded text-slate-300">
                      Medical Aid: <span className="font-bold text-emerald-400">{shelter.hasMedicalAid ? 'Available' : 'None'}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <a
                      href={`tel:${shelter.contactPhone}`}
                      className="flex-1 text-center py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold rounded text-slate-200 border border-slate-700"
                    >
                      📞 {shelter.contactPhone}
                    </a>
                    {onSelectForEvac && (
                      <button
                        onClick={() => onSelectForEvac(shelter)}
                        className="flex-1 py-1.5 px-2 bg-emerald-600 hover:bg-emerald-500 text-xs font-bold rounded text-white shadow-md shadow-emerald-600/30 flex items-center justify-center gap-1"
                      >
                        <Navigation2 className="w-3.5 h-3.5" />
                        Safe Route
                      </button>
                    )}
                  </div>
                </div>
              </Popup>
            </Marker>
          );
        })}

        {/* Citizen SOS Reports */}
        {filterLayer.reports && reports.map(report => {
          const isPending = report.status === 'pending';
          const icon = createCustomIcon(
            isPending ? '#f59e0b' : '#38bdf8',
            '🆘'
          );

          return (
            <Marker
              key={report._id || report.id}
              position={[report.location.lat, report.location.lng]}
              icon={icon}
            >
              <Popup>
                <div className="p-2 max-w-xs text-slate-100 font-sans">
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded text-white ${
                      isPending ? 'bg-amber-600' : 'bg-blue-600'
                    }`}>
                      {report.status.toUpperCase()}
                    </span>
                    <span className="text-[10px] text-slate-400">{new Date(report.createdAt).toLocaleTimeString()}</span>
                  </div>
                  <h3 className="font-bold text-sm text-white mb-1">{report.title}</h3>
                  <p className="text-xs text-slate-300 mb-2">{report.description}</p>
                  
                  {report.imageUrl && (
                    <img
                      src={report.imageUrl}
                      alt="Incident evidence"
                      className="w-full h-24 object-cover rounded-lg mb-2 border border-slate-700"
                    />
                  )}

                  <div className="text-[11px] text-slate-400">
                    <div>Reporter: <span className="text-slate-200">{report.reporterName}</span></div>
                    {report.victimsCount > 0 && (
                      <div className="text-red-400 font-semibold">Trapped / Victims: {report.victimsCount} people</div>
                    )}
                  </div>
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>
    </div>
  );
};

export default LiveMap;
