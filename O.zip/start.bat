@echo off
title ResQ-Alert | Real-Time Disaster Alert & Emergency Response System
echo ===================================================================
echo   ResQ-Alert: Real-Time Disaster Alert and Emergency Response System
echo ===================================================================
echo.

set PATH=C:\Users\Sai Lahari\.gemini\antigravity\tools\node;%PATH%

echo Checking environment...
node -v >nul 2>&1
if %errorlevel% neq 0 (
  echo Error: Node.js runtime not found. Please ensure Node.js is installed.
  pause
  exit /b 1
)

echo.
echo [1/2] Checking backend dependencies...
cd backend
if not exist node_modules (
  echo Installing backend dependencies...
  call npm install
)

echo.
echo [2/2] Starting Unified Emergency Response Server (Port 5000)...
echo.
echo Access URL: http://localhost:5000
echo.

start "" "http://localhost:5000"
node server.js
pause
