import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import LiveMap from './components/LiveMap';
import EvacuationNav from './components/EvacuationNav';
import AlertsFeed from './components/AlertsFeed';
import ShelterLocator from './components/ShelterLocator';
import SafetyGuides from './components/SafetyGuides';
import AdminDashboard from './components/AdminDashboard';
import ReportSOSModal from './components/ReportSOSModal';
import AuthModal from './components/AuthModal';
import LocationPickerModal from './components/LocationPickerModal';
import MyReportsTracker from './components/MyReportsTracker';
import { useAuth } from './context/AuthContext';
import { useSocket } from './context/SocketContext';
import { useLocation } from './context/LocationContext';
import { alertService, shelterService, reportService } from './services/api';
import {
  AlertTriangle,
  Radio,
  PhoneCall,
  Volume2,
  X,
  Shield,
  Layers,
  Heart
} from 'lucide-react';

function App() {
  const [activeTab, setActiveTab] = useState('map');
  const [alerts, setAlerts] = useState([]);
  const [shelters, setShelters] = useState([]);
  const [reports, setReports] = useState([]);
  const [selectedShelterForEvac, setSelectedShelterForEvac] = useState(null);

  // Modals
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const { isAuthority } = useAuth();
  const { latestBroadcast, dismissBroadcast, playSirenSound } = useSocket();
  const { currentLocation } = useLocation();

  // Load initial dataset — re-fires whenever the user changes their location
  const fetchInitialData = async (loc) => {
    try {
      const locParams = loc && loc.lat ? {
        userLat: loc.lat,
        userLng: loc.lng,
        cityName: loc.name || loc.city || ''
      } : {};

      const [alertsRes, sheltersRes, reportsRes] = await Promise.all([
        alertService.getAll(locParams),
        shelterService.getAll(locParams),
        reportService.getAll()
      ]);

      if (alertsRes.data.success) setAlerts(alertsRes.data.alerts);
      if (sheltersRes.data.success) setShelters(sheltersRes.data.shelters);
      if (reportsRes.data.success) setReports(reportsRes.data.reports);
    } catch (err) {
      console.warn('Initial data load warning:', err.message);
    }
  };

  useEffect(() => {
    fetchInitialData(currentLocation);
  }, [currentLocation?.lat, currentLocation?.lng]);

  // When a new citizen report is submitted, add to local list immediately
  const handleReportSubmitted = (newReport) => {
    setReports(prev => [newReport, ...prev]);
  };

  const handleSelectShelterForEvac = (shelter) => {
    setSelectedShelterForEvac(shelter);
    setActiveTab('evac');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-red-600 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenReportModal={() => setIsReportModalOpen(true)}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
      />

      {/* Real-Time Live Emergency Broadcast Siren Popup Overlay */}
      {latestBroadcast && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-red-950/85 backdrop-blur-md animate-pulse-fast">
          <div className="relative w-full max-w-lg bg-slate-900 border-2 border-red-500 rounded-3xl p-6 shadow-2xl shadow-red-500/50 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-red-500/20 text-red-500 border border-red-500/40 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-10 h-10 animate-bounce" />
            </div>

            <div className="space-y-1">
              <span className="text-[11px] font-mono font-bold uppercase tracking-widest text-red-400 bg-red-500/10 px-3 py-1 rounded-full border border-red-500/30">
                CRITICAL EMERGENCY BROADCAST SIREN
              </span>
              <h2 className="text-2xl font-black text-white mt-2 leading-tight">
                {latestBroadcast.alert?.title || latestBroadcast.notification?.title}
              </h2>
            </div>

            <p className="text-sm text-slate-300 leading-relaxed max-w-md mx-auto">
              {latestBroadcast.alert?.description || latestBroadcast.notification?.message}
            </p>

            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs font-mono text-amber-400">
              📍 Area: {latestBroadcast.alert?.location?.area || 'All Designated Zones'} • Follow Evacuation Corridors
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => {
                  dismissBroadcast();
                  setActiveTab('evac');
                }}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase shadow-lg shadow-emerald-600/30 transition-all"
              >
                Navigate Safe Route
              </button>
              <button
                onClick={dismissBroadcast}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition-all"
              >
                Acknowledge & Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1">
        {activeTab === 'map' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <LiveMap
              alerts={alerts}
              shelters={shelters}
              reports={reports}
              onSelectForEvac={handleSelectShelterForEvac}
            />
          </div>
        )}

        {activeTab === 'alerts' && (
          <AlertsFeed
            alerts={alerts}
            onNavigateToMap={() => setActiveTab('map')}
            onNavigateToEvac={() => setActiveTab('evac')}
          />
        )}

        {activeTab === 'evac' && (
          <EvacuationNav
            shelters={shelters}
            alerts={alerts}
            selectedShelter={selectedShelterForEvac}
          />
        )}

        {activeTab === 'shelters' && (
          <ShelterLocator
            shelters={shelters}
            onSelectForEvac={handleSelectShelterForEvac}
          />
        )}

        {activeTab === 'guides' && (
          <SafetyGuides />
        )}

        {activeTab === 'tracker' && (
          <MyReportsTracker onOpenReportModal={() => setIsReportModalOpen(true)} />
        )}

        {activeTab === 'admin' && (
          <AdminDashboard />
        )}
      </main>

      {/* Citizen SOS Reporting Modal */}
      <ReportSOSModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        onReportSubmitted={handleReportSubmitted}
        onGoToTracker={() => setActiveTab('tracker')}
      />

      {/* Global Location Selector Modal */}
      <LocationPickerModal />

      {/* Login & Register Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      {/* Academic Project Footer */}
      <footer className="bg-slate-900/90 border-t border-slate-800 py-6 px-4 mt-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-red-600 flex items-center justify-center text-white font-bold text-xs">
              R
            </div>
            <span className="font-semibold text-slate-300">ResQ-Alert System</span>
            <span className="text-slate-600">|</span>
            <span>Web Technologies Capstone Project</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 font-mono text-[11px]">
            <span className="bg-slate-800 px-2.5 py-1 rounded-md text-slate-300">React.js + Tailwind</span>
            <span className="bg-slate-800 px-2.5 py-1 rounded-md text-slate-300">Node.js + Express</span>
            <span className="bg-slate-800 px-2.5 py-1 rounded-md text-slate-300">Socket.io WebSockets</span>
            <span className="bg-slate-800 px-2.5 py-1 rounded-md text-slate-300">Leaflet Maps</span>
            <span className="bg-slate-800 px-2.5 py-1 rounded-md text-slate-300">Dual-Mode MongoDB</span>
          </div>

          <div className="text-slate-500 text-center md:text-right">
            Designed for High-Reliability Emergency Management & Public Safety
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
