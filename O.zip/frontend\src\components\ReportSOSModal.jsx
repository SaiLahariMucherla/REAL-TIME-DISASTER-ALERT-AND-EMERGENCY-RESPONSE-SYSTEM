import React, { useState } from 'react';
import {
  X,
  AlertTriangle,
  Camera,
  MapPin,
  Users,
  CheckCircle,
  Loader2,
  UploadCloud,
  Crosshair
} from 'lucide-react';
import { reportService } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useLocation } from '../context/LocationContext';
import confetti from 'canvas-confetti';

const ReportSOSModal = ({ isOpen, onClose, onReportSubmitted, onGoToTracker }) => {
  const { user } = useAuth();
  const { currentLocation } = useLocation();
  const [formData, setFormData] = useState({
    title: '',
    disasterType: 'flood',
    severity: 'critical',
    description: '',
    address: currentLocation.address || currentLocation.name || 'Current Emergency Location',
    lat: currentLocation.lat || 17.3850,
    lng: currentLocation.lng || 78.4867,
    victimsCount: 1,
    imageUrl: ''
  });

  // Keep location updated if context location changes and modal opens
  React.useEffect(() => {
    if (isOpen) {
      setFormData(prev => ({
        ...prev,
        address: currentLocation.address || currentLocation.name,
        lat: currentLocation.lat,
        lng: currentLocation.lng
      }));
    }
  }, [isOpen, currentLocation]);

  const [imagePreview, setImagePreview] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [locating, setLocating] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [successData, setSuccessData] = useState(null);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  // Handle auto-detect location
  const handleDetectGPS = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setFormData(prev => ({
          ...prev,
          lat: parseFloat(pos.coords.latitude.toFixed(5)),
          lng: parseFloat(pos.coords.longitude.toFixed(5)),
          address: `GPS: ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`
        }));
        setLocating(false);
      },
      (err) => {
        console.warn('GPS detection failed, fallback coordinates retained:', err.message);
        setLocating(false);
      },
      { timeout: 8000 }
    );
  };

  // Handle photo selection
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  // Quick preset sample image for instant demo presentation
  const handleUseSamplePhoto = () => {
    const sampleUrl = 'https://images.unsplash.com/photo-1547683905-f686c993aae5?auto=format&fit=crop&w=600&q=80';
    setImagePreview(sampleUrl);
    setFormData(prev => ({ ...prev, imageUrl: sampleUrl }));
    setSelectedFile(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setErrorMessage('');

    try {
      const payload = new FormData();
      payload.append('title', formData.title || `${formData.disasterType.toUpperCase()} Emergency at ${formData.address}`);
      payload.append('disasterType', formData.disasterType);
      payload.append('severity', formData.severity);
      payload.append('description', formData.description);
      payload.append('location', JSON.stringify({
        address: formData.address,
        lat: formData.lat,
        lng: formData.lng
      }));
      payload.append('victimsCount', formData.victimsCount);
      payload.append('reporterName', user ? user.name : 'Citizen Alert');
      payload.append('reporterPhone', user ? user.phone : '+91-9123456789');

      if (selectedFile) {
        payload.append('image', selectedFile);
      } else if (formData.imageUrl) {
        payload.append('imageUrl', formData.imageUrl);
      }

      const res = await reportService.create(payload);
      if (res.data.success) {
        setSuccessData(res.data.report);
        const reportId = res.data.report._id || res.data.report.id;
        try {
          const mySaved = JSON.parse(localStorage.getItem('resq_my_reports') || '[]');
          if (!mySaved.includes(reportId)) {
            mySaved.unshift(reportId);
            localStorage.setItem('resq_my_reports', JSON.stringify(mySaved));
          }
        } catch (e) {}

        if (onReportSubmitted) onReportSubmitted(res.data.report);
        confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
      }
    } catch (err) {
      console.error('Report submission error:', err);
      setErrorMessage(err.response?.data?.message || 'Failed to transmit emergency report. Please try again or dial 112 directly.');
    } finally {
      setSubmitting(false);
    }
  };

  const resetAndClose = () => {
    setSuccessData(null);
    setImagePreview(null);
    setSelectedFile(null);
    setErrorMessage('');
    onClose();
  };

  const handleTrackNow = () => {
    const data = successData;
    resetAndClose();
    if (onGoToTracker) onGoToTracker(data);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-600 to-orange-600 p-5 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-black tracking-tight">Citizen Emergency SOS Incident Report</h2>
              <p className="text-xs text-red-100">Directly synchronized to the National Disaster Response Command Center</p>
            </div>
          </div>
          <button
            onClick={resetAndClose}
            className="p-2 rounded-xl bg-black/20 hover:bg-black/40 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          {successData ? (
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto">
                <CheckCircle className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-black text-white">Emergency SOS Transmitted!</h3>
              <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                Your incident report has been received and verified by the Disaster Management Cell.
                Response personnel have been notified at GPS coordinates <code className="text-emerald-400 font-mono">[{successData.location.lat}, {successData.location.lng}]</code>.
              </p>
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-left max-w-sm mx-auto text-xs space-y-1.5 font-mono">
                <div className="text-slate-400">Incident Reference ID: <span className="text-white font-bold">{successData._id}</span></div>
                <div className="text-slate-400">Initial Status: <span className="text-amber-400 uppercase font-bold">{successData.status}</span></div>
                <div className="text-slate-400">Emergency Hotline: <span className="text-red-400 font-bold">112 / 1078</span></div>
              </div>
              <div className="pt-4 flex flex-col sm:flex-row justify-center gap-3">
                <button
                  onClick={handleTrackNow}
                  className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider shadow-lg shadow-amber-500/20 transition-all"
                >
                  Track Officer Approval Status Now →
                </button>
                <button
                  onClick={resetAndClose}
                  className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
                >
                  Close Window
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {errorMessage && (
                <div className="p-3 rounded-xl bg-red-500/20 border border-red-500/40 text-red-300 text-xs">
                  {errorMessage}
                </div>
              )}

              {/* Disaster Category & Urgency */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                    Disaster Category *
                  </label>
                  <select
                    value={formData.disasterType}
                    onChange={(e) => setFormData({ ...formData, disasterType: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-red-500"
                  >
                    <option value="flood">🌊 Flood / Inundation</option>
                    <option value="cyclone">🌀 Cyclone / Hurricane Squall</option>
                    <option value="earthquake">⚡ Earthquake / Building Tremor</option>
                    <option value="wildfire">🔥 Wildfire / High Heat Blaze</option>
                    <option value="landslide">⛰️ Landslide / Debris Fall</option>
                    <option value="other">⚠️ Other High-Risk Emergency</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                    Urgency Severity Level *
                  </label>
                  <select
                    value={formData.severity}
                    onChange={(e) => setFormData({ ...formData, severity: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-red-500"
                  >
                    <option value="critical">🔴 CRITICAL (Immediate Life Threat)</option>
                    <option value="high">🟠 HIGH (Urgent Rescue Required)</option>
                    <option value="moderate">🟡 MODERATE (Property / Access Risk)</option>
                  </select>
                </div>
              </div>

              {/* Brief Title */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Emergency Headline / Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 5 Residents Trapped on Rooftop by Rising Water"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-red-500"
                />
              </div>

              {/* Location & GPS Auto Detect */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                    Incident Location & GPS Coordinates *
                  </label>
                  <button
                    type="button"
                    onClick={handleDetectGPS}
                    disabled={locating}
                    className="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1"
                  >
                    <Crosshair className={`w-3.5 h-3.5 ${locating ? 'animate-spin' : ''}`} />
                    {locating ? 'Locating...' : 'Auto-Detect My GPS'}
                  </button>
                </div>
                <input
                  type="text"
                  required
                  placeholder="Street Address, Landmark or Locality"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-red-500 mb-2"
                />
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="flex items-center gap-2 bg-slate-950 px-3 py-2 rounded-xl border border-slate-800">
                    <span className="text-slate-500 font-mono">LAT:</span>
                    <input
                      type="number"
                      step="any"
                      value={formData.lat}
                      onChange={(e) => setFormData({ ...formData, lat: parseFloat(e.target.value) })}
                      className="bg-transparent text-white font-mono w-full focus:outline-none"
                    />
                  </div>
                  <div className="flex items-center gap-2 bg-slate-950 px-3 py-2 rounded-xl border border-slate-800">
                    <span className="text-slate-500 font-mono">LNG:</span>
                    <input
                      type="number"
                      step="any"
                      value={formData.lng}
                      onChange={(e) => setFormData({ ...formData, lng: parseFloat(e.target.value) })}
                      className="bg-transparent text-white font-mono w-full focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Victims Count & Detailed Description */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-1">
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                    Trapped Persons / Victims
                  </label>
                  <div className="flex items-center bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2">
                    <Users className="w-4 h-4 text-slate-400 mr-2" />
                    <input
                      type="number"
                      min="0"
                      value={formData.victimsCount}
                      onChange={(e) => setFormData({ ...formData, victimsCount: parseInt(e.target.value, 10) || 0 })}
                      className="w-full bg-transparent text-sm text-white focus:outline-none"
                    />
                  </div>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                    Situation Details & Hazards *
                  </label>
                  <textarea
                    rows={2}
                    required
                    placeholder="Describe severity, immediate risks (live wires, water depth, debris)..."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-red-500"
                  />
                </div>
              </div>

              {/* Photo Upload & Preview */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                    Attach Incident Photo / Evidence
                  </label>
                  <button
                    type="button"
                    onClick={handleUseSamplePhoto}
                    className="text-xs text-amber-400 hover:text-amber-300 font-medium underline"
                  >
                    Attach Sample Disaster Photo (Demo)
                  </button>
                </div>

                <div className="flex items-center gap-4">
                  <label className="flex-1 border-2 border-dashed border-slate-700 hover:border-red-500 rounded-2xl p-4 cursor-pointer text-center bg-slate-950/60 transition-colors">
                    <UploadCloud className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                    <span className="text-xs text-slate-300 block font-medium">Click to upload photo from device</span>
                    <span className="text-[10px] text-slate-500">PNG, JPG, WEBP up to 10MB</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="hidden"
                    />
                  </label>

                  {imagePreview && (
                    <div className="w-24 h-24 rounded-2xl overflow-hidden border border-slate-700 relative shrink-0">
                      <img
                        src={imagePreview}
                        alt="Incident preview"
                        className="w-full h-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={() => { setImagePreview(null); setSelectedFile(null); setFormData(p => ({ ...p, imageUrl: '' })); }}
                        className="absolute top-1 right-1 p-1 bg-black/70 rounded-full text-white"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Submit CTA */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-xl shadow-red-600/30 active:scale-98 transition-all disabled:opacity-50"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span>Transmitting SOS to Authorities...</span>
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="w-5 h-5" />
                      <span>TRANSMIT EMERGENCY SOS REPORT</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReportSOSModal;
