const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  phone: { type: String, default: '' },
  role: { type: String, enum: ['citizen', 'authority'], default: 'citizen' },
  location: {
    city: String,
    lat: Number,
    lng: Number
  },
  createdAt: { type: Date, default: Date.now }
});

const AlertSchema = new mongoose.Schema({
  title: { type: String, required: true },
  type: {
    type: String,
    enum: ['flood', 'cyclone', 'earthquake', 'wildfire', 'landslide', 'tsunami', 'storm', 'other'],
    required: true
  },
  severity: {
    type: String,
    enum: ['critical', 'high', 'moderate', 'low'],
    default: 'high'
  },
  description: { type: String, required: true },
  location: {
    area: { type: String, required: true },
    city: { type: String, default: '' },
    lat: { type: Number, required: true },
    lng: { type: Number, required: true },
    radiusKm: { type: Number, default: 15 }
  },
  instructions: [{ type: String }],
  source: { type: String, default: 'National Disaster Management Authority' },
  active: { type: Boolean, default: true },
  issuedAt: { type: Date, default: Date.now },
  expiresAt: { type: Date }
});

const IncidentReportSchema = new mongoose.Schema({
  title: { type: String, required: true },
  disasterType: { type: String, required: true },
  severity: { type: String, enum: ['critical', 'high', 'moderate', 'minor'], default: 'high' },
  description: { type: String, required: true },
  location: {
    address: { type: String, required: true },
    lat: { type: Number, required: true },
    lng: { type: Number, required: true }
  },
  imageUrl: { type: String, default: '' },
  reporterName: { type: String, default: 'Anonymous Citizen' },
  reporterPhone: { type: String, default: '' },
  status: {
    type: String,
    enum: ['pending', 'verified', 'dispatched', 'resolved', 'dismissed'],
    default: 'pending'
  },
  victimsCount: { type: Number, default: 0 },
  dispatchedUnit: { type: String, default: '' },
  adminNotes: { type: String, default: '' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

const ShelterSchema = new mongoose.Schema({
  name: { type: String, required: true },
  type: { type: String, enum: ['shelter', 'hospital', 'relief_camp'], default: 'shelter' },
  location: {
    address: { type: String, required: true },
    city: { type: String, required: true },
    lat: { type: Number, required: true },
    lng: { type: Number, required: true }
  },
  totalCapacity: { type: Number, default: 500 },
  currentOccupancy: { type: Number, default: 0 },
  availableBeds: { type: Number, default: 500 },
  hasMedicalAid: { type: Boolean, default: true },
  hasFoodWater: { type: Boolean, default: true },
  contactPhone: { type: String, default: '1078' },
  status: { type: String, enum: ['open', 'nearing_capacity', 'full', 'closed'], default: 'open' }
});

module.exports = {
  User: mongoose.models.User || mongoose.model('User', UserSchema),
  Alert: mongoose.models.Alert || mongoose.model('Alert', AlertSchema),
  IncidentReport: mongoose.models.IncidentReport || mongoose.model('IncidentReport', IncidentReportSchema),
  Shelter: mongoose.models.Shelter || mongoose.model('Shelter', ShelterSchema)
};
