import React, { useState } from 'react';
import {
  X,
  MapPin,
  Crosshair,
  Search,
  Globe,
  Sliders,
  CheckCircle,
  Loader2
} from 'lucide-react';
import { useLocation } from '../context/LocationContext';

const LocationPickerModal = () => {
  const {
    currentLocation,
    locationModalOpen,
    setLocationModalOpen,
    setManualLocation,
    searchAndSetLocation,
    detectGPSLocation,
    presetLocations,
    isLocating
  } = useLocation();

  const [searchQuery, setSearchQuery] = useState('');
  const [customLat, setCustomLat] = useState(currentLocation.lat);
  const [customLng, setCustomLng] = useState(currentLocation.lng);
  const [customName, setCustomName] = useState(currentLocation.name);
  const [isSearching, setIsSearching] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');

  if (!locationModalOpen) return null;

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    setStatusMsg('');
    const success = await searchAndSetLocation(searchQuery);
    setIsSearching(false);
    if (success) {
      setLocationModalOpen(false);
    } else {
      setStatusMsg('Location not found. Try another city name or enter latitude and longitude directly below.');
    }
  };

  const handleApplyCustomCoords = (e) => {
    e.preventDefault();
    setManualLocation(
      customName || `Custom Pin (${parseFloat(customLat).toFixed(3)}, ${parseFloat(customLng).toFixed(3)})`,
      parseFloat(customLat),
      parseFloat(customLng)
    );
    setLocationModalOpen(false);
  };

  const handleSelectPreset = (p) => {
    setManualLocation(p.name, p.lat, p.lng);
    setLocationModalOpen(false);
  };

  const handleGPSClick = async () => {
    try {
      await detectGPSLocation();
      setLocationModalOpen(false);
    } catch (e) {
      // Handled in context alert
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">Set Your Active Location</h2>
              <p className="text-xs text-slate-400">
                Choose any city worldwide, auto-detect GPS, or enter custom coordinates
              </p>
            </div>
          </div>
          <button
            onClick={() => setLocationModalOpen(false)}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current Active Location Pill */}
        <div className="p-4 bg-blue-950/30 border-b border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-slate-400 font-medium">Currently Selected:</span>
            <span className="font-bold text-white">{currentLocation.name}</span>
          </div>
          <span className="font-mono text-blue-400 font-semibold">
            [{currentLocation.lat.toFixed(4)}, {currentLocation.lng.toFixed(4)}]
          </span>
        </div>

        <div className="p-6 overflow-y-auto space-y-6">
          {/* Option 1: GPS Auto Detect */}
          <div>
            <button
              onClick={handleGPSClick}
              disabled={isLocating}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 active:scale-98 transition-all disabled:opacity-50"
            >
              {isLocating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Requesting Device GPS Sensor...</span>
                </>
              ) : (
                <>
                  <Crosshair className="w-4 h-4" />
                  <span>Auto-Detect My Current GPS Location</span>
                </>
              )}
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="h-[1px] bg-slate-800 flex-1" />
            <span className="text-[11px] font-mono text-slate-500 uppercase">OR SEARCH ANY CITY</span>
            <div className="h-[1px] bg-slate-800 flex-1" />
          </div>

          {/* Option 2: Search City / Place */}
          <form onSubmit={handleSearch} className="space-y-2">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Enter any city, district, or landmark (e.g. Visakhapatnam, Mumbai, London)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
              </div>
              <button
                type="submit"
                disabled={isSearching}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition-colors shrink-0"
              >
                {isSearching ? 'Searching...' : 'Find & Set'}
              </button>
            </div>
            {statusMsg && (
              <p className="text-xs text-amber-400">{statusMsg}</p>
            )}
          </form>

          {/* Popular City Quick-Select Presets */}
          <div>
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2.5">
              Quick Select Major Cities & Disaster Zones:
            </div>
            <div className="flex flex-wrap gap-1.5">
              {presetLocations.map((p) => {
                const isSelected = currentLocation.name.includes(p.name.split(',')[0]);
                return (
                  <button
                    key={p.name}
                    onClick={() => handleSelectPreset(p)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      isSelected
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                        : 'bg-slate-950 border border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white'
                    }`}
                  >
                    📍 {p.name.split(',')[0]}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="h-[1px] bg-slate-800 flex-1" />
            <span className="text-[11px] font-mono text-slate-500 uppercase">OR CUSTOM COORDINATES</span>
            <div className="h-[1px] bg-slate-800 flex-1" />
          </div>

          {/* Option 3: Manual Lat / Lng Coords Input */}
          <form onSubmit={handleApplyCustomCoords} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-blue-400" />
              Manual Coordinate Entry
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Place Name</label>
                <input
                  type="text"
                  placeholder="My Home / Office"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Latitude</label>
                <input
                  type="number"
                  step="any"
                  required
                  value={customLat}
                  onChange={(e) => setCustomLat(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] font-mono text-slate-400 uppercase mb-1">Longitude</label>
                <input
                  type="number"
                  step="any"
                  required
                  value={customLng}
                  onChange={(e) => setCustomLng(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white border border-slate-700 transition-colors"
            >
              Apply Exact Coordinates
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LocationPickerModal;
