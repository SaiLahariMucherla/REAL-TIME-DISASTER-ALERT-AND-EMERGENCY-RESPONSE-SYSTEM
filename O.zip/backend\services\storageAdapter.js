const fs = require('fs');
const path = require('path');
const config = require('../config/config');

// Ensure data and upload directories exist
if (!fs.existsSync(config.DATA_DIR)) {
  fs.mkdirSync(config.DATA_DIR, { recursive: true });
}
if (!fs.existsSync(config.UPLOADS_DIR)) {
  fs.mkdirSync(config.UPLOADS_DIR, { recursive: true });
}

class JsonCollection {
  constructor(name) {
    this.name = name;
    this.filePath = path.join(config.DATA_DIR, `${name}.json`);
    this.data = [];
    this.load();
  }

  load() {
    try {
      if (fs.existsSync(this.filePath)) {
        const raw = fs.readFileSync(this.filePath, 'utf-8');
        this.data = JSON.parse(raw);
      } else {
        this.data = [];
        this.save();
      }
    } catch (err) {
      console.warn(`[JsonCollection:${this.name}] Load error, starting empty:`, err.message);
      this.data = [];
    }
  }

  save() {
    try {
      fs.writeFileSync(this.filePath, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error(`[JsonCollection:${this.name}] Save error:`, err.message);
    }
  }

  find(filter = {}) {
    return this.data.filter(item => {
      for (const key of Object.keys(filter)) {
        if (filter[key] !== undefined && item[key] !== filter[key]) {
          return false;
        }
      }
      return true;
    });
  }

  findById(id) {
    return this.data.find(item => item._id === id || item.id === id) || null;
  }

  findOne(filter = {}) {
    const list = this.find(filter);
    return list.length > 0 ? list[0] : null;
  }

  create(doc) {
    const record = {
      _id: doc._id || 'id_' + Math.random().toString(36).substring(2, 11) + Date.now().toString(36),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      ...doc
    };
    this.data.unshift(record);
    this.save();
    return record;
  }

  findByIdAndUpdate(id, update, options = {}) {
    const index = this.data.findIndex(item => item._id === id || item.id === id);
    if (index === -1) return null;

    const updated = {
      ...this.data[index],
      ...update,
      updatedAt: new Date().toISOString()
    };
    this.data[index] = updated;
    this.save();
    return updated;
  }

  findByIdAndDelete(id) {
    const index = this.data.findIndex(item => item._id === id || item.id === id);
    if (index === -1) return null;
    const removed = this.data.splice(index, 1)[0];
    this.save();
    return removed;
  }

  countDocuments(filter = {}) {
    return this.find(filter).length;
  }

  clear() {
    this.data = [];
    this.save();
  }
}

const collections = {
  users: new JsonCollection('users'),
  alerts: new JsonCollection('alerts'),
  reports: new JsonCollection('reports'),
  shelters: new JsonCollection('shelters'),
  notifications: new JsonCollection('notifications')
};

module.exports = {
  collections,
  JsonCollection
};
